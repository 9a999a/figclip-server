"""The website's API (Flask). Everything is JSON under /api, plus the file download route /dl/..."""
import base64
import hashlib
import math
import secrets
import time

import requests
from flask import Flask, abort, g, jsonify, redirect, request, send_file, session
from flask_cors import CORS
from werkzeug.middleware.proxy_fix import ProxyFix

from . import auth, db, library, payments, safety, worker
from .config import S


def create_app():
    app = Flask(__name__)
    app.config["SECRET_KEY"] = S.SECRET_KEY
    app.config["SESSION_COOKIE_SECURE"] = S.COOKIE_SECURE
    app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
    app.config["MAX_CONTENT_LENGTH"] = 64 * 1024
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)
    CORS(app, origins=[S.SITE_ORIGIN], supports_credentials=True)
    S.FILES_DIR.mkdir(parents=True, exist_ok=True)

    def err(message, code):
        return jsonify({"error": message}), code

    # ------------------------------------------------------------ request plumbing
    @app.before_request
    def _guard():
        if request.method in ("POST", "PUT", "DELETE", "PATCH"):
            origin = request.headers.get("Origin")
            if origin and origin != S.SITE_ORIGIN:
                return err("Forbidden", 403)
        g.user = auth.user_from_token(request.cookies.get(auth.COOKIE))

    @app.after_request
    def _headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["Referrer-Policy"] = "no-referrer"
        if request.path.startswith("/api/"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.errorhandler(404)
    def _404(_):
        return err("Not found", 404)

    @app.errorhandler(405)
    def _405(_):
        return err("Method not allowed", 405)

    @app.errorhandler(413)
    def _413(_):
        return err("Request too large", 413)

    @app.errorhandler(payments.PayError)
    def _pay(e):
        return err(str(e), e.status)

    def body():
        d = request.get_json(silent=True)
        return d if isinstance(d, dict) else {}

    def login_required():
        if g.user is None:
            abort(401)

    @app.errorhandler(401)
    def _401(_):
        return err("Please sign in", 401)

    def set_cookie(resp, token):
        resp.set_cookie(auth.COOKIE, token, max_age=auth.SESSION_SECONDS, httponly=True,
                        secure=S.COOKIE_SECURE, samesite="Lax", path="/")
        return resp

    def user_payload(u):
        t = int(time.time())
        member = u["member_until"] > t
        return {
            "email": u["email"], "x_handle": u["x_handle"], "x_linked": bool(u["x_user_id"]),
            "member": member, "member_until": u["member_until"],
            "days_left": math.ceil((u["member_until"] - t) / 86400) if member else 0,
            "reply_mode": u["reply_mode"],
        }

    # ------------------------------------------------------------ auth
    @app.get("/api/health")
    def health():
        return jsonify({"ok": True})

    @app.post("/api/auth/register")
    def register():
        d = body()
        email, pw = auth.norm_email(d.get("email")), d.get("password")
        if auth.rate_limited(f"reg:{request.remote_addr}", 10, 3600):
            return err("Too many attempts. Try again later.", 429)
        if not auth.valid_email(email):
            return err("Enter a valid email.", 400)
        if not auth.valid_password(pw):
            return err("Password must be at least 8 characters.", 400)
        uid = auth.create_user(email, pw)
        if uid is None:
            return err("This email is already registered.", 409)
        return set_cookie(jsonify({"ok": True}), auth.new_session(uid))

    @app.post("/api/auth/login")
    def login():
        d = body()
        email, pw = auth.norm_email(d.get("email")), d.get("password")
        if (auth.rate_limited(f"login-ip:{request.remote_addr}", 30, 600)
                or auth.rate_limited(f"login-email:{email}", 8, 600)):
            return err("Too many attempts. Try again in a few minutes.", 429)
        uid = auth.check_login(email, pw) if isinstance(pw, str) else None
        if uid is None:
            return err("Wrong email or password.", 401)
        return set_cookie(jsonify({"ok": True}), auth.new_session(uid))

    @app.post("/api/auth/logout")
    def logout():
        auth.end_session(request.cookies.get(auth.COOKIE))
        resp = jsonify({"ok": True})
        resp.delete_cookie(auth.COOKIE, path="/")
        return resp

    @app.post("/api/auth/forgot")
    def forgot():
        email = auth.norm_email(body().get("email"))
        if auth.rate_limited(f"forgot-ip:{request.remote_addr}", 10, 3600) or auth.rate_limited(f"forgot:{email}", 3, 3600):
            return err("Too many attempts. Try again later.", 429)
        row = db.conn().execute("SELECT id FROM users WHERE email=?", (email,)).fetchone() if auth.valid_email(email) else None
        if row:
            token = auth.make_reset_token(row["id"])
            auth.send_email(email, "Reset your FigClip password",
                            f"Open this link to choose a new password (valid for 1 hour):\n"
                            f"{S.SITE_ORIGIN}/auth.html#reset={token}\n\nIf you did not ask for this, ignore this email.")
        return jsonify({"ok": True})  # same answer whether or not the email exists

    @app.post("/api/auth/reset")
    def reset():
        d = body()
        if auth.rate_limited(f"reset:{request.remote_addr}", 10, 3600):
            return err("Too many attempts. Try again later.", 429)
        if not auth.valid_password(d.get("password")):
            return err("Password must be at least 8 characters.", 400)
        if not auth.use_reset_token(str(d.get("token", "")), d["password"]):
            return err("This reset link is invalid or expired.", 400)
        return jsonify({"ok": True})

    # ------------------------------------------------------------ account
    @app.get("/api/me")
    def me():
        login_required()
        return jsonify(user_payload(g.user))

    @app.post("/api/me/password")
    def change_password():
        login_required()
        d = body()
        if auth.rate_limited(f"pw:{g.user['id']}", 8, 600):
            return err("Too many attempts. Try again later.", 429)
        if auth.check_login(g.user["email"], d.get("current") or "") is None:
            return err("Current password is wrong.", 400)
        if not auth.valid_password(d.get("new")):
            return err("New password must be at least 8 characters.", 400)
        auth.change_password(g.user["id"], d["new"])
        auth.end_all_sessions(g.user["id"], keep_token=request.cookies.get(auth.COOKIE))
        return jsonify({"ok": True})

    @app.post("/api/me/reply-mode")
    def reply_mode():
        login_required()
        mode = body().get("mode")
        if mode not in ("public", "dm"):
            return err("Invalid choice.", 400)
        if mode == "dm" and not library.is_member(g.user):
            return err("Sending links by DM is for members.", 403)
        db.conn().execute("UPDATE users SET reply_mode=? WHERE id=?", (mode, g.user["id"]))
        return jsonify({"ok": True, "reply_mode": mode})

    @app.get("/api/notifications")
    def notifications():
        login_required()
        rows = db.conn().execute("SELECT text, at FROM notifications WHERE user_id=? ORDER BY at DESC LIMIT 30",
                                 (g.user["id"],)).fetchall()
        return jsonify({"items": [{"text": r["text"], "at": r["at"]} for r in rows]})

    @app.get("/api/downloads")
    def downloads():
        login_required()
        member = library.is_member(g.user)
        rows = db.conn().execute(
            "SELECT uv.at, uv.label, v.key AS vkey, v.token, v.status FROM user_videos uv"
            " LEFT JOIN videos v ON v.id = uv.video_id WHERE uv.user_id=? ORDER BY uv.at DESC LIMIT 200",
            (g.user["id"],)).fetchall()
        items = []
        for r in rows:
            if not member:  # visible but locked: no id, no source, only the time
                items.append({"at": r["at"], "locked": True})
                continue
            key = r["vkey"] or ""
            items.append({"at": r["at"], "locked": False, "source": r["label"],
                          "tweet_id": key[2:] if key.startswith("x:") else None,
                          "link": f"{S.SITE_ORIGIN}/v/{r['token']}" if r["token"] and r["status"] == "ready" else None})
        return jsonify({"member": member, "items": items})

    @app.delete("/api/downloads")
    def clear_downloads():
        login_required()
        if not library.is_member(g.user):
            return err("Members only.", 403)
        db.conn().execute("DELETE FROM user_videos WHERE user_id=?", (g.user["id"],))
        return jsonify({"ok": True})

    @app.post("/api/support")
    def support():
        d = body()
        msg = str(d.get("message", "")).strip()
        if not msg or len(msg) > 2000:
            return err("Write a message (up to 2000 characters).", 400)
        email = g.user["email"] if g.user else auth.norm_email(d.get("email"))
        if not g.user and not auth.valid_email(email):
            return err("Enter your email so we can reply.", 400)
        if auth.rate_limited(f"support:{request.remote_addr}", 5, 3600):
            return err("Too many messages. Try again later.", 429)
        db.conn().execute("INSERT INTO support (user_id, email, message, at) VALUES (?,?,?,?)",
                          (g.user["id"] if g.user else None, email, msg, int(time.time())))
        if S.SUPPORT_EMAIL:
            auth.send_email(S.SUPPORT_EMAIL, f"Support message from {email}", msg)
        return jsonify({"ok": True})

    # ------------------------------------------------------------ link my X account (OAuth 2.0 + PKCE)
    @app.get("/api/x/start")
    def x_start():
        login_required()
        if not S.X_OAUTH_CLIENT_ID:
            return err("Linking is not available yet.", 503)
        verifier = secrets.token_urlsafe(64)
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
        state = secrets.token_urlsafe(24)
        session["x_state"], session["x_verifier"], session["x_user"] = state, verifier, g.user["id"]
        q = requests.Request("GET", "https://x.com/i/oauth2/authorize", params={
            "response_type": "code", "client_id": S.X_OAUTH_CLIENT_ID,
            "redirect_uri": f"{S.PUBLIC_BASE_URL}/api/x/callback", "scope": "users.read tweet.read",
            "state": state, "code_challenge": challenge, "code_challenge_method": "S256"}).prepare().url
        return redirect(q)

    @app.get("/api/x/callback")
    def x_callback():
        back = f"{S.SITE_ORIGIN}/app.html#/account"
        state, verifier, uid = session.pop("x_state", None), session.pop("x_verifier", None), session.pop("x_user", None)
        if not state or state != request.args.get("state") or not request.args.get("code") or g.user is None \
                or g.user["id"] != uid:
            return redirect(back + "?x=failed")
        try:
            tok = requests.post(f"{S.X_API_BASE}/2/oauth2/token", auth=(S.X_OAUTH_CLIENT_ID, S.X_OAUTH_CLIENT_SECRET),
                                data={"grant_type": "authorization_code", "code": request.args["code"],
                                      "redirect_uri": f"{S.PUBLIC_BASE_URL}/api/x/callback",
                                      "code_verifier": verifier, "client_id": S.X_OAUTH_CLIENT_ID}, timeout=20)
            tok.raise_for_status()
            who = requests.get(f"{S.X_API_BASE}/2/users/me", timeout=20,
                               headers={"Authorization": f"Bearer {tok.json()['access_token']}"})
            who.raise_for_status()
            data = who.json()["data"]
        except (requests.RequestException, KeyError, ValueError):
            return redirect(back + "?x=failed")
        try:
            db.conn().execute("UPDATE users SET x_user_id=?, x_handle=? WHERE id=?",
                              (data["id"], data.get("username"), g.user["id"]))
        except Exception:  # this X account is already linked to another user
            return redirect(back + "?x=taken")
        return redirect(back + "?x=linked")

    # ------------------------------------------------------------ memberships and payments
    @app.post("/api/orders")
    def new_order():
        login_required()
        d = body()
        months = d.get("months")
        months = months if isinstance(months, int) and not isinstance(months, bool) else 0
        oid = payments.create_order(g.user["id"], months, d.get("method"))
        return jsonify(payments.view(payments.get_order(oid, g.user["id"])))

    @app.get("/api/order/<oid>")
    def order_status(oid):
        login_required()
        o = payments.get_order(oid, g.user["id"])
        if o["method"] == "usdt":
            o = payments.check_usdt(o)
        return jsonify(payments.view(o))

    @app.post("/api/order/<oid>/paypal/create")
    def paypal_create(oid):
        login_required()
        o = payments.get_order(oid, g.user["id"])
        return jsonify({"id": payments.paypal_create(o)})

    @app.post("/api/order/<oid>/paypal/capture")
    def paypal_capture(oid):
        login_required()
        o = payments.get_order(oid, g.user["id"])
        return jsonify(payments.view(payments.paypal_capture(o)))

    @app.get("/api/prices")
    def prices():
        from . import pricing
        return jsonify({str(m): {"usdt": str(pricing.price_for(m, "usdt")), "paypal": str(pricing.price_for(m, "paypal")),
                                 "days": pricing.days_for(m)} for m in pricing.PLANS})

    # ------------------------------------------------------------ the link page and downloads
    @app.get("/api/link/<token>")
    def link_info(token):
        v = library.get_by_token(token)
        if v is None or v["status"] != "ready":
            return err("This link does not exist.", 404)
        if not library.link_open(v, g.user):
            return err("This link has expired.", 410)
        t = int(time.time())
        member = library.is_member(g.user)
        return jsonify({
            "label": v["label"], "duration": v["duration"],
            "seconds_left": max(0, v["expires_at"] - t) if not member else None,
            "member": member, "options": library.view_variants(v, g.user),
        })

    @app.get("/dl/<token>/<int:tier>")
    def download(token, tier):
        v = library.get_by_token(token)
        if v is None or not library.link_open(v, g.user):
            abort(404)
        match = next((x for x in library.variants_of(v) if x["tier"] == tier), None)
        if match is None:
            abort(404)
        if not library.tier_allowed(tier, library.is_member(g.user)):
            return err("This quality is for members.", 403)
        path = (library.video_dir(v["id"]) / match["file"]).resolve()
        if library.video_dir(v["id"]).resolve() not in path.parents or not path.is_file():
            abort(404)
        ext = path.suffix or ".mp4"
        return send_file(path, as_attachment=True, download_name=f"figclip-{tier}p{ext}", conditional=True)

    # ------------------------------------------------------------ test-only endpoints
    if S.DEV_MODE:
        @app.post("/api/dev/submit")
        def dev_submit():
            d = body()
            jid = worker.enqueue(str(d.get("url", "")), user_id=d.get("user_id"), is_member=bool(d.get("member")))
            return jsonify({"job": jid}) if jid else err("rejected", 400)

        @app.get("/api/dev/job/<int:jid>")
        def dev_job(jid):
            j = db.conn().execute("SELECT * FROM jobs WHERE id=?", (jid,)).fetchone()
            if j is None:
                abort(404)
            v = library.get_by_key(j["key"])
            return jsonify({"status": j["status"], "token": v["token"] if v else None})

    return app
