"""Telegram front door: a person sends an X link to the bot, the bot sends back the figclip.com download link.

Uses long polling (getUpdates), so it needs no public webhook and costs nothing. Same queue, same engine and the
same quality rules as the X bot. A chat that is not linked to a site account is treated as a free user.
The person picks one of 12 languages with the buttons shown by /start; the choice is remembered per chat.
"""
import logging
import re
import time

import requests

from . import db, safety, xapi
from .config import S

log = logging.getLogger("figclip.telegram")

URL_RE = re.compile(r"https?://[^\s<>\"']+", re.I)

LANGS = [  # same 12 languages, in the order of the picker
    ("ar", "العربية"), ("en", "English"), ("es", "Español"), ("fa", "فارسی"),
    ("hi", "हिन्दी"), ("id", "Bahasa Indonesia"), ("ja", "日本語"), ("pt", "Português"),
    ("ru", "Русский"), ("tr", "Türkçe"), ("zh", "简体中文"), ("zh-TW", "繁體中文"),
]
CODES = {c for c, _ in LANGS}

WELCOME = {
    "en": "Hi 👋 I'm FigClip. Send me a link to an X (Twitter) post with a video and I'll send you a download link.",
    "ar": "أهلًا 👋 أنا FigClip. أرسل لي رابط تغريدة من X فيها فيديو، وأرسل لك رابط التنزيل.",
    "es": "Hola 👋 Soy FigClip. Envíame el enlace de una publicación de X (Twitter) con un video y te enviaré un enlace de descarga.",
    "fa": "سلام 👋 من FigClip هستم. لینک پستی از X (توییتر) که ویدیو دارد را برایم بفرست تا لینک دانلود را برایت بفرستم.",
    "hi": "नमस्ते 👋 मैं FigClip हूँ। मुझे X (Twitter) की किसी वीडियो वाली पोस्ट का लिंक भेजें, मैं आपको डाउनलोड लिंक भेज दूँगा।",
    "id": "Halo 👋 Saya FigClip. Kirim tautan postingan X (Twitter) yang berisi video, dan saya akan mengirimkan tautan unduhan.",
    "ja": "こんにちは 👋 FigClipです。動画付きのX（Twitter）の投稿リンクを送ってください。ダウンロードリンクをお送りします。",
    "pt": "Olá 👋 Eu sou o FigClip. Envie o link de uma publicação do X (Twitter) com vídeo e eu envio um link de download.",
    "ru": "Привет 👋 Я FigClip. Отправьте ссылку на пост в X (Twitter) с видео, и я пришлю ссылку для скачивания.",
    "tr": "Merhaba 👋 Ben FigClip. Videolu bir X (Twitter) gönderisinin bağlantısını gönder, sana indirme bağlantısı göndereyim.",
    "zh": "你好 👋 我是 FigClip。把带视频的 X（Twitter）帖子链接发给我，我会把下载链接发给你。",
    "zh-TW": "你好 👋 我是 FigClip。把附有影片的 X（Twitter）貼文連結傳給我，我會把下載連結傳給你。",
}
NO_LINK = {
    "en": "Send me the link of an X (Twitter) post that has a video.",
    "ar": "أرسل لي رابط تغريدة من X فيها فيديو.",
    "es": "Envíame el enlace de una publicación de X (Twitter) que tenga un video.",
    "fa": "لینک یک پست X (توییتر) که ویدیو دارد را برایم بفرست.",
    "hi": "मुझे X (Twitter) की किसी वीडियो वाली पोस्ट का लिंक भेजें।",
    "id": "Kirim tautan postingan X (Twitter) yang berisi video.",
    "ja": "動画付きのX（Twitter）の投稿リンクを送ってください。",
    "pt": "Envie o link de uma publicação do X (Twitter) que tenha vídeo.",
    "ru": "Отправьте ссылку на пост в X (Twitter) с видео.",
    "tr": "Videolu bir X (Twitter) gönderisinin bağlantısını gönder.",
    "zh": "请发送带视频的 X（Twitter）帖子链接。",
    "zh-TW": "請傳送附有影片的 X（Twitter）貼文連結。",
}
SLOW = {
    "en": "Too many requests. Please try again in a little while.",
    "ar": "طلبات كثيرة. حاول بعد قليل.",
    "es": "Demasiadas solicitudes. Inténtalo de nuevo en un rato.",
    "fa": "درخواست‌ها زیاد است. کمی بعد دوباره امتحان کن.",
    "hi": "बहुत ज़्यादा अनुरोध। कृपया थोड़ी देर बाद फिर कोशिश करें।",
    "id": "Terlalu banyak permintaan. Coba lagi sebentar lagi.",
    "ja": "リクエストが多すぎます。しばらくしてからもう一度お試しください。",
    "pt": "Muitas solicitações. Tente novamente daqui a pouco.",
    "ru": "Слишком много запросов. Попробуйте чуть позже.",
    "tr": "Çok fazla istek. Lütfen biraz sonra tekrar dene.",
    "zh": "请求过多，请稍后再试。",
    "zh-TW": "請求過多，請稍後再試。",
}
FAILED = {
    "en": "I couldn't get a video from this link. Check that the post has a video and try again.",
    "ar": "ما قدرت أجيب فيديو من هذا الرابط. تأكد أن التغريدة فيها فيديو وجرّب مرة ثانية.",
    "es": "No pude obtener un video de este enlace. Comprueba que la publicación tenga video e inténtalo de nuevo.",
    "fa": "نتوانستم از این لینک ویدیویی بگیرم. مطمئن شو پست ویدیو دارد و دوباره امتحان کن.",
    "hi": "इस लिंक से वीडियो नहीं मिल सका। जाँचें कि पोस्ट में वीडियो है और फिर कोशिश करें।",
    "id": "Saya tidak bisa mengambil video dari tautan ini. Pastikan postingan memiliki video lalu coba lagi.",
    "ja": "このリンクから動画を取得できませんでした。投稿に動画があるか確認して、もう一度お試しください。",
    "pt": "Não consegui obter um vídeo deste link. Verifique se a publicação tem vídeo e tente novamente.",
    "ru": "Не удалось получить видео по этой ссылке. Убедитесь, что в посте есть видео, и попробуйте снова.",
    "tr": "Bu bağlantıdan video alamadım. Gönderide video olduğundan emin ol ve tekrar dene.",
    "zh": "无法从此链接获取视频。请确认帖子包含视频后重试。",
    "zh-TW": "無法從此連結取得影片。請確認貼文包含影片後再試一次。",
}
TOO_LONG = {
    "en": "This video is longer than {minutes} minutes. Members can download longer videos: {site}",
    "ar": "هذا الفيديو أطول من {minutes} دقيقة. المشتركون يستطيعون تحميل الفيديوهات الأطول: {site}",
    "es": "Este video dura más de {minutes} minutos. Los miembros pueden descargar videos más largos: {site}",
    "fa": "این ویدیو بیش از {minutes} دقیقه است. اعضا می‌توانند ویدیوهای طولانی‌تر را دانلود کنند: {site}",
    "hi": "यह वीडियो {minutes} मिनट से लंबा है। सदस्य लंबे वीडियो डाउनलोड कर सकते हैं: {site}",
    "id": "Video ini lebih panjang dari {minutes} menit. Member dapat mengunduh video yang lebih panjang: {site}",
    "ja": "この動画は{minutes}分を超えています。メンバーはより長い動画をダウンロードできます：{site}",
    "pt": "Este vídeo tem mais de {minutes} minutos. Membros podem baixar vídeos mais longos: {site}",
    "ru": "Это видео длиннее {minutes} минут. Участники могут скачивать более длинные видео: {site}",
    "tr": "Bu video {minutes} dakikadan uzun. Üyeler daha uzun videoları indirebilir: {site}",
    "zh": "此视频超过 {minutes} 分钟。会员可以下载更长的视频：{site}",
    "zh-TW": "此影片超過 {minutes} 分鐘。會員可以下載更長的影片：{site}",
}


def _guess(code):
    """Telegram's language_code -> one of our 12 (default English)."""
    c = str(code or "").lower().replace("_", "-")
    if c.startswith("zh"):
        return "zh-TW" if any(x in c for x in ("tw", "hk", "hant", "mo")) else "zh"
    base = c.split("-")[0]
    return base if base in CODES else "en"


def chat_lang(chat_id, telegram_code=None):
    row = db.conn().execute("SELECT lang FROM tg_chats WHERE chat_id=?", (str(chat_id),)).fetchone()
    return row["lang"] if row and row["lang"] in CODES else _guess(telegram_code)


def _picker():
    rows, row = [], []
    for code, name in LANGS:
        row.append({"text": name, "callback_data": "lang:" + code})
        if len(row) == 2:
            rows.append(row)
            row = []
    return {"inline_keyboard": rows}


def _call(method, payload, timeout=15):
    r = requests.post(f"https://api.telegram.org/bot{S.TG_BOT_TOKEN}/{method}", json=payload, timeout=timeout)
    if r.status_code >= 400:
        raise RuntimeError(f"telegram {method} -> {r.status_code}")
    return r.json()


def say(chat_id, text, reply_to=None, keyboard=None):
    payload = {"chat_id": chat_id, "text": text, "disable_web_page_preview": True}
    if keyboard:
        payload["reply_markup"] = keyboard
    if reply_to:
        payload["reply_parameters"] = {"message_id": int(reply_to), "allow_sending_without_reply": True}
    try:
        _call("sendMessage", payload)
    except Exception as e:
        log.warning("send failed: %s", e)


def find_x_link(text):
    for raw in URL_RE.findall(text or ""):
        url = raw.rstrip(").,!?،؛")
        if safety.x_status_id(url):
            return url
    return None


def _recent(chat_id):
    return db.conn().execute("SELECT COUNT(*) c FROM jobs WHERE tg_chat_id=? AND enqueued_at>?",
                             (str(chat_id), int(time.time()) - 3600)).fetchone()["c"]


def handle(msg):
    from . import worker  # late import: worker imports this module
    chat = (msg.get("chat") or {})
    if chat.get("type") != "private":
        return  # private chats only
    chat_id, mid = chat.get("id"), msg.get("message_id")
    lang = chat_lang(chat_id, (msg.get("from") or {}).get("language_code"))
    text = (msg.get("text") or msg.get("caption") or "").strip()
    cmd = text.split()[0].split("@")[0].lower() if text else ""
    if cmd in ("/start", "/help", "/language", "/lang"):
        return say(chat_id, WELCOME[lang], keyboard=_picker())
    url = find_x_link(text)
    if not url:
        return say(chat_id, NO_LINK[lang], mid)
    if _recent(chat_id) >= S.TG_PER_HOUR:
        return say(chat_id, SLOW[lang], mid)
    jid = worker.enqueue(url, lang=lang, tg_chat_id=str(chat_id), tg_msg_id=str(mid))
    if jid is None:  # a blocked or unsafe link
        return say(chat_id, FAILED[lang], mid)
    try:
        _call("sendChatAction", {"chat_id": chat_id, "action": "typing"})
    except Exception:
        pass


def handle_choice(cb):
    """The person tapped a language button."""
    data = cb.get("data") or ""
    chat = (cb.get("message") or {}).get("chat") or {}
    code = data[5:] if data.startswith("lang:") else ""
    try:
        _call("answerCallbackQuery", {"callback_query_id": cb.get("id")})
    except Exception:
        pass
    if chat.get("type") != "private" or code not in CODES:
        return
    db.conn().execute("INSERT OR REPLACE INTO tg_chats VALUES (?, ?)", (str(chat["id"]), code))
    say(chat["id"], WELCOME[code], keyboard=_picker())


def _job_lang(job):
    return job["lang"] if job["lang"] in CODES else "en"


def send_link(job, video):
    link = f"{S.SITE_ORIGIN}/v/{video['token']}"
    say(job["tg_chat_id"], xapi.REPLY.get(_job_lang(job), xapi.REPLY["en"]).format(url=link), job["tg_msg_id"])


def send_problem(job, error):
    lang = _job_lang(job)
    if error == "too_long":
        text = TOO_LONG[lang].format(minutes=S.FREE_MAX_SECONDS // 60, site=S.SITE_ORIGIN)
    else:
        text = FAILED[lang]
    say(job["tg_chat_id"], text, job["tg_msg_id"])


def _offset():
    row = db.conn().execute("SELECT v FROM state WHERE k='tg_offset'").fetchone()
    return int(row["v"]) if row else 0


def poll_once():
    """One long-poll round. Called in a loop by the worker."""
    try:
        data = _call("getUpdates", {"offset": _offset(), "timeout": 25,
                                    "allowed_updates": ["message", "callback_query"]}, timeout=40)
    except Exception as e:
        log.warning("poll failed: %s", e)
        time.sleep(5)
        return
    for upd in data.get("result") or []:
        db.conn().execute("INSERT OR REPLACE INTO state VALUES ('tg_offset', ?)", (str(upd["update_id"] + 1),))
        try:
            if upd.get("message"):
                handle(upd["message"])
            elif upd.get("callback_query"):
                handle_choice(upd["callback_query"])
        except Exception:
            log.exception("update crashed")
