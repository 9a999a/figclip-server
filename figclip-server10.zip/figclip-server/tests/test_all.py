import time

import pytest

from figclip import db, library, pricing, safety, worker, xapi
from figclip.config import S

ORIGIN = {"Origin": "https://figclip.com"}


def register(client, email="a@b.com", pw="password1"):
    r = client.post("/api/auth/register", json={"email": email, "password": pw}, headers=ORIGIN)
    assert r.status_code == 200, r.json
    return r


def run_job(url="https://x.com/i/status/1230000000000", **kw):
    jid = worker.enqueue(url, **kw)
    assert jid
    job = worker.claim_next()
    worker.process(job)
    return job


def token_for(key="x:1230000000000"):
    return library.get_by_key(key)["token"]


# ---------------- pricing
def test_prices():
    assert str(pricing.price_for(1, "usdt")) == "1.00"
    assert str(pricing.price_for(3, "usdt")) == "3.00"
    assert str(pricing.price_for(6, "usdt")) == "5.40"
    assert str(pricing.price_for(12, "usdt")) == "9.00"
    assert str(pricing.price_for(1, "paypal")) == "1.00"
    assert str(pricing.price_for(12, "paypal")) == "9.50"
    assert [pricing.days_for(m) for m in (1, 3, 6, 12)] == [30, 90, 180, 365]


# ---------------- safety
@pytest.mark.parametrize("url", ["http://127.0.0.1/a", "http://localhost/a", "file:///etc/passwd", "ftp://x.com/a",
                                 "http://10.0.0.1/a", "https://user:pw@example.com/a", "http://example.com:22/a",
                                 "http://169.254.169.254/latest"])
def test_unsafe_urls(url):
    with pytest.raises(safety.UnsafeURL):
        safety.validate_url(url)


def test_x_canonical():
    assert safety.canonical_source("https://twitter.com/foo/status/1230000000000?s=20") == "https://x.com/i/status/1230000000000"
    assert safety.cache_key("https://x.com/i/status/1230000000000") == "x:1230000000000"


# ---------------- auth
def test_register_login_logout(client):
    register(client)
    assert client.get("/api/me").json["email"] == "a@b.com"
    client.post("/api/auth/logout", headers=ORIGIN)
    assert client.get("/api/me").status_code == 401
    assert client.post("/api/auth/login", json={"email": "a@b.com", "password": "bad"}, headers=ORIGIN).status_code == 401
    assert client.post("/api/auth/login", json={"email": "a@b.com", "password": "password1"}, headers=ORIGIN).status_code == 200


def test_duplicate_and_weak(client):
    register(client)
    assert client.post("/api/auth/register", json={"email": "a@b.com", "password": "password1"}, headers=ORIGIN).status_code == 409
    assert client.post("/api/auth/register", json={"email": "c@b.com", "password": "123"}, headers=ORIGIN).status_code == 400


def test_bad_origin_rejected(client):
    r = client.post("/api/auth/login", json={"email": "a@b.com", "password": "x"}, headers={"Origin": "https://evil.com"})
    assert r.status_code == 403


def test_login_rate_limit(client):
    register(client)
    codes = [client.post("/api/auth/login", json={"email": "a@b.com", "password": "bad"}, headers=ORIGIN).status_code
             for _ in range(10)]
    assert 429 in codes


def test_password_reset(client):
    from figclip import auth
    register(client)
    uid = db.conn().execute("SELECT id FROM users").fetchone()["id"]
    tok = auth.make_reset_token(uid)
    assert client.post("/api/auth/reset", json={"token": tok, "password": "newpassword"}, headers=ORIGIN).status_code == 200
    assert client.post("/api/auth/reset", json={"token": tok, "password": "another123"}, headers=ORIGIN).status_code == 400
    assert client.post("/api/auth/login", json={"email": "a@b.com", "password": "newpassword"}, headers=ORIGIN).status_code == 200


def test_forgot_same_answer(client):
    assert client.post("/api/auth/forgot", json={"email": "nobody@x.com"}, headers=ORIGIN).json == {"ok": True}


# ---------------- queue
def test_queue_followers_first_then_waiting_jump():
    now = int(time.time())
    a = worker.enqueue("https://x.com/i/status/10000000000", tweet_id="t1", is_follower=False)
    b = worker.enqueue("https://x.com/i/status/20000000000", tweet_id="t2", is_follower=True)
    assert worker.claim_next()["id"] == b          # follower first
    c = db.conn()
    c.execute("UPDATE jobs SET status='queued' WHERE id=?", (b,))
    c.execute("UPDATE jobs SET enqueued_at=? WHERE id=?", (now - 120, a))  # a has waited > 60 s
    assert worker.claim_next()["id"] == a          # waiting request jumps ahead


def test_duplicate_tweet_ignored():
    assert worker.enqueue("https://x.com/i/status/10000000000", tweet_id="t1")
    assert worker.enqueue("https://x.com/i/status/10000000000", tweet_id="t1") is None


def test_blocked_not_fetched():
    db.conn().execute("INSERT INTO blocked VALUES ('x:90000000000','takedown',0)")
    assert worker.enqueue("https://x.com/i/status/90000000000") is None


# ---------------- link page and downloads
def test_free_visitor_sees_locked_tiers(client):
    run_job()
    info = client.get(f"/api/link/{token_for()}").json
    tiers = {o["tier"]: o for o in info["options"]}
    assert not tiers[480]["locked"] and "url" in tiers[480]
    assert tiers[720]["locked"] and "url" not in tiers[720]
    assert tiers[1080]["locked"] and "url" not in tiers[1080]
    assert info["seconds_left"] > 7000


def test_locked_download_refused(client):
    run_job()
    t = token_for()
    assert client.get(f"/dl/{t}/480").status_code == 200
    assert client.get(f"/dl/{t}/1080").status_code == 403
    assert client.get(f"/dl/{t}/999").status_code == 404
    assert client.get("/dl/nonsense/480").status_code == 404


def test_file_is_served_exactly(client):
    run_job()
    r = client.get(f"/dl/{token_for()}/480")
    assert r.data == b"x" * 4800  # untouched bytes


def test_member_gets_all(client):
    register(client)
    uid = db.conn().execute("SELECT id FROM users").fetchone()["id"]
    library.extend_membership(uid, 30)
    run_job()
    assert client.get(f"/dl/{token_for()}/1080").status_code == 200
    info = client.get(f"/api/link/{token_for()}").json
    assert not any(o["locked"] for o in info["options"])


def test_free_link_expires(client):
    run_job()
    t = token_for()
    db.conn().execute("UPDATE videos SET expires_at=?", (int(time.time()) - 1,))
    assert client.get(f"/api/link/{t}").status_code == 410
    assert client.get(f"/dl/{t}/480").status_code == 404
    library.cleanup()
    assert library.get_by_key("x:1230000000000") is None


def test_path_traversal(client):
    run_job()
    assert client.get("/dl/..%2f..%2fetc/480").status_code == 404


# ---------------- member library
def test_downloads_list_locked_for_free_user(client):
    register(client)
    uid = db.conn().execute("SELECT id FROM users").fetchone()["id"]
    run_job(user_id=uid)
    items = client.get("/api/downloads").json["items"]
    assert len(items) == 1 and items[0]["locked"] and "link" not in items[0]
    library.extend_membership(uid, 30)
    items = client.get("/api/downloads").json["items"]
    assert not items[0]["locked"] and items[0]["link"]


def test_member_video_survives_expiry_and_grace():
    from figclip import library as L
    u = db.conn().execute("INSERT INTO users (email, pw_hash, created_at, member_until) VALUES ('m@x.com','x',0,?)",
                          (int(time.time()) + 86400,)).lastrowid
    run_job(user_id=u, is_member=True)
    db.conn().execute("UPDATE videos SET expires_at=?", (int(time.time()) - 10,))
    L.cleanup()
    assert L.get_by_key("x:1230000000000") is not None            # member still active
    db.conn().execute("UPDATE users SET member_until=?", (int(time.time()) - S.GRACE_SECONDS - 10,))
    L.cleanup()
    assert L.get_by_key("x:1230000000000") is None                # grace over


def test_reply_mode_dm_members_only(client):
    register(client)
    assert client.post("/api/me/reply-mode", json={"mode": "dm"}, headers=ORIGIN).status_code == 403
    uid = db.conn().execute("SELECT id FROM users").fetchone()["id"]
    library.extend_membership(uid, 30)
    assert client.post("/api/me/reply-mode", json={"mode": "dm"}, headers=ORIGIN).status_code == 200


# ---------------- payments
def test_usdt_order_flow(client, monkeypatch):
    from figclip import payments
    register(client)
    r = client.post("/api/orders", json={"months": 3, "method": "usdt"}, headers=ORIGIN)
    assert r.status_code == 200, r.json
    o = r.json
    assert float(o["amount"]) >= 3.0001 and o["address"] == "TTestAddress"
    monkeypatch.setattr(payments, "binance_deposits", lambda since: [
        {"amount": o["amount"], "txId": "tx1", "insertTime": int(time.time() * 1000), "status": 1, "coin": "USDT", "address": "TTestAddress"}])
    monkeypatch.setattr(payments, "_last_reconcile", 0, raising=False)
    s = client.get(f"/api/order/{o['id']}").json
    assert s["status"] == "paid"
    me = client.get("/api/me").json
    assert me["member"] and 89 <= me["days_left"] <= 90
    client.get(f"/api/order/{o['id']}")  # polling again must not extend twice
    assert 89 <= client.get("/api/me").json["days_left"] <= 90


def test_bad_order_inputs(client):
    register(client)
    assert client.post("/api/orders", json={"months": 2, "method": "usdt"}, headers=ORIGIN).status_code == 400
    assert client.post("/api/orders", json={"months": 1, "method": "cash"}, headers=ORIGIN).status_code == 400
    assert client.post("/api/orders", json={"months": True, "method": "usdt"}, headers=ORIGIN).status_code == 400


def test_other_users_order_hidden(client):
    register(client)
    oid = client.post("/api/orders", json={"months": 1, "method": "usdt"}, headers=ORIGIN).json["id"]
    other = client.application.test_client()
    other.post("/api/auth/register", json={"email": "z@b.com", "password": "password1"}, headers=ORIGIN)
    assert other.get(f"/api/order/{oid}").status_code in (403, 404)


# ---------------- X
def test_reply_languages():
    assert "الرابط" in xapi.reply_text("ar", "U") or "رابط" in xapi.reply_text("ar", "U")
    assert xapi.pick_lang("und", "ja") == "ja" or xapi.pick_lang("und") == "en"
    assert xapi.pick_lang("xx") == "en"


def test_poll_once_dry_run(monkeypatch):
    class C:
        def mentions(self, since):
            return [{"id": "500", "author_id": "7", "handle": "bob", "lang": "ar", "refs": [{"type": "replied_to", "id": "1230000000000"}], "urls": []}]
        def tweet(self, tid):
            return {"id": tid, "lang": "ar", "has_video": True, "urls": []}
    monkeypatch.setattr(S, "X_BOT_USER_ID", "1")
    worker.poll_once(C())
    job = worker.claim_next()
    assert job["key"] == "x:1230000000000" and job["tweet_id"] == "500"
    worker.process(job)
    assert db.conn().execute("SELECT status FROM jobs").fetchone()["status"] == "done"


def test_no_video_stays_silent(monkeypatch):
    class C:
        def mentions(self, since):
            return [{"id": "501", "author_id": "7", "handle": "bob", "lang": "en", "refs": [], "urls": []}]
        def tweet(self, tid):
            return {"id": tid, "lang": "en", "has_video": False, "urls": []}
    monkeypatch.setattr(S, "X_BOT_USER_ID", "1")
    worker.poll_once(C())
    assert worker.claim_next() is None


def test_failed_build_is_silent(monkeypatch):
    from figclip import engine
    def boom(*a, **k):
        raise engine.EngineError("nope")
    monkeypatch.setattr(engine, "build", boom)
    jid = worker.enqueue("https://x.com/i/status/550000000000", tweet_id="t55")
    worker.process(worker.claim_next())
    assert db.conn().execute("SELECT status FROM jobs WHERE id=?", (jid,)).fetchone()["status"] == "failed"
    assert library.get_by_key("x:550000000000") is None


def test_too_long(monkeypatch):
    from figclip import engine
    def long(*a, **k):
        raise engine.TooLong(5000, 1200)
    monkeypatch.setattr(engine, "build", long)
    jid = worker.enqueue("https://x.com/i/status/560000000000", tweet_id="t56")
    worker.process(worker.claim_next())
    assert db.conn().execute("SELECT status FROM jobs WHERE id=?", (jid,)).fetchone()["status"] == "too_long"


def test_support(client):
    assert client.post("/api/support", json={"message": "hi", "email": "q@x.com"}, headers=ORIGIN).status_code == 200
    assert client.post("/api/support", json={"message": "", "email": "q@x.com"}, headers=ORIGIN).status_code == 400


def test_usdt_wrong_network_not_paid(client, monkeypatch):
    from figclip import payments
    register(client)
    o = client.post("/api/orders", json={"months": 1, "method": "usdt"}, headers=ORIGIN).json
    monkeypatch.setattr(payments, "binance_deposits", lambda since: [
        {"amount": o["amount"], "txId": "tx9", "status": 1, "coin": "USDT", "network": "BSC"}])
    monkeypatch.setattr(payments, "_last_reconcile", 0, raising=False)
    assert client.get(f"/api/order/{o['id']}").json["status"] == "pending"


def test_x_link_members_only(client):
    register(client)
    assert client.get("/api/x/start").status_code == 403
    uid = db.conn().execute("SELECT id FROM users").fetchone()["id"]
    library.extend_membership(uid, 30)
    assert client.get("/api/x/start").status_code == 503  # member allowed; X app not configured in tests


def _dep(amount, tx):
    return {"amount": str(amount), "txId": tx, "insertTime": int(time.time() * 1000), "status": 1, "coin": "USDT"}


def test_usdt_fee_tolerance(client, monkeypatch):
    from decimal import Decimal
    from figclip import payments
    register(client)
    o = client.post("/api/orders", json={"months": 1, "method": "usdt"}, headers=ORIGIN).json
    short = Decimal(o["amount"]) - Decimal("0.20")           # fees taken out: accepted (the cap is 25% of the order)
    monkeypatch.setattr(payments, "binance_deposits", lambda since: [_dep(short, "tf1")])
    monkeypatch.setattr(payments, "_last_reconcile", 0, raising=False)
    assert client.get(f"/api/order/{o['id']}").json["status"] == "paid"


def test_usdt_too_short_not_paid(client, monkeypatch):
    from decimal import Decimal
    from figclip import payments
    register(client)
    o = client.post("/api/orders", json={"months": 1, "method": "usdt"}, headers=ORIGIN).json
    short = Decimal(o["amount"]) - Decimal("0.30")           # more than 25% below: not accepted
    monkeypatch.setattr(payments, "binance_deposits", lambda since: [_dep(short, "tf2")])
    monkeypatch.setattr(payments, "_last_reconcile", 0, raising=False)
    assert client.get(f"/api/order/{o['id']}").json["status"] == "pending"


def test_usdt_ambiguous_short_deposit_waits(client, monkeypatch):
    from decimal import Decimal
    from figclip import payments
    register(client)
    a = client.post("/api/orders", json={"months": 1, "method": "usdt"}, headers=ORIGIN).json
    b = client.post("/api/orders", json={"months": 1, "method": "usdt"}, headers=ORIGIN).json
    short = min(Decimal(a["amount"]), Decimal(b["amount"])) - Decimal("0.10")
    monkeypatch.setattr(payments, "binance_deposits", lambda since: [_dep(short, "tf3")])
    monkeypatch.setattr(payments, "_last_reconcile", 0, raising=False)
    assert client.get(f"/api/order/{a['id']}").json["status"] == "pending"
    assert client.get(f"/api/order/{b['id']}").json["status"] == "pending"


def test_reply_tags_the_asker():
    from figclip import xapi
    assert xapi.with_handle("abc_1", "hi").startswith("@abc_1 hi")
    assert xapi.with_handle(None, "hi") == "hi"
    assert xapi.with_handle("bad handle!", "hi") == "hi"


def test_mentions_follower_flag(monkeypatch):
    from figclip import xapi
    from figclip.config import S
    monkeypatch.setattr(S, "FOLLOW_CHECK", "mentions", raising=False)
    class R:
        status_code = 200
        def json(self):
            return {"data": [{"id": "9", "author_id": "1", "text": "x"}, {"id": "8", "author_id": "2", "text": "y"}],
                    "includes": {"users": [{"id": "1", "username": "a", "connection_status": ["followed_by"]},
                                           {"id": "2", "username": "b", "connection_status": []}]}}
    class Sess:
        def get(self, *a, **k): return R()
    out = xapi.XClient(session=Sess()).mentions()
    flags = {m["author_id"]: m["is_follower"] for m in out}
    assert flags == {"1": True, "2": False}


def test_member_can_delete_one_download(client):
    from figclip import library as L
    register(client)
    uid = db.conn().execute("SELECT id FROM users").fetchone()["id"]
    run_job(user_id=uid, is_member=True)
    # a free user cannot delete
    assert client.delete("/api/downloads/whatever", headers=ORIGIN).status_code == 403
    L.extend_membership(uid, 30)
    item = client.get("/api/downloads").json["items"][0]
    assert item["ref"]
    assert client.delete("/api/downloads/nope", headers=ORIGIN).status_code == 404
    assert client.delete(f"/api/downloads/{item['ref']}", headers=ORIGIN).status_code == 200
    assert client.get("/api/downloads").json["items"] == []
    # once the free window is over nobody keeps it, so cleanup removes the file
    db.conn().execute("UPDATE videos SET expires_at=?", (int(time.time()) - 10,))
    L.cleanup()
    assert L.get_by_key("x:1230000000000") is None


def test_delete_download_of_another_user_is_404(client):
    from figclip import library as L
    register(client)
    uid = db.conn().execute("SELECT id FROM users").fetchone()["id"]
    L.extend_membership(uid, 30)
    other = db.conn().execute("INSERT INTO users (email, pw_hash, created_at, member_until) VALUES ('o@x.com','x',0,?)",
                              (int(time.time()) + 86400,)).lastrowid
    run_job(user_id=other, is_member=True)
    token = db.conn().execute("SELECT token FROM videos").fetchone()["token"]
    assert client.delete(f"/api/downloads/{token}", headers=ORIGIN).status_code == 404
    assert db.conn().execute("SELECT COUNT(*) c FROM user_videos WHERE user_id=?", (other,)).fetchone()["c"] == 1


# ---------------- Telegram
def _tg_sent(monkeypatch):
    from figclip import telegram
    sent = []
    monkeypatch.setattr(telegram, "_call", lambda method, payload, timeout=15: sent.append((method, payload)) or {"result": []})
    return sent


def _msg(text, chat=77, lang="en", kind="private"):
    return {"message_id": 5, "chat": {"id": chat, "type": kind}, "from": {"language_code": lang}, "text": text}


def test_telegram_x_link_gets_download_link(monkeypatch):
    from figclip import telegram
    sent = _tg_sent(monkeypatch)
    telegram.handle(_msg("look https://x.com/someone/status/1230000000000?s=20 please"))
    job = worker.claim_next()
    assert job["tg_chat_id"] == "77" and job["key"] == "x:1230000000000"
    worker.process(job)
    texts = [p["text"] for m, p in sent if m == "sendMessage"]
    assert len(texts) == 1 and "figclip" in texts[0].lower() or "/v/" in texts[0]
    assert "/v/" in texts[0]


def test_telegram_ignores_groups_and_asks_for_link(monkeypatch):
    from figclip import telegram
    sent = _tg_sent(monkeypatch)
    telegram.handle(_msg("https://x.com/a/status/1230000000000", kind="group"))
    assert sent == [] and worker.claim_next() is None
    telegram.handle(_msg("hello"))
    assert sent[-1][1]["text"] == telegram.NO_LINK["en"]
    telegram.handle(_msg("/start", lang="ar"))
    assert sent[-1][1]["text"] == telegram.WELCOME["ar"]
    assert len(sent[-1][1]["reply_markup"]["inline_keyboard"]) == 6   # 12 languages, two per row


def test_telegram_rate_limit(monkeypatch):
    from figclip import telegram
    sent = _tg_sent(monkeypatch)
    monkeypatch.setattr(S, "TG_PER_HOUR", 2, raising=False)
    for i in range(3):
        telegram.handle(_msg(f"https://x.com/a/status/12300000000{i}0"))
    assert sent[-1][1]["text"] == telegram.SLOW["en"]
    n = db.conn().execute("SELECT COUNT(*) c FROM jobs").fetchone()["c"]
    assert n == 2


def test_telegram_language_choice_sticks(monkeypatch):
    from figclip import telegram
    sent = _tg_sent(monkeypatch)
    cb = {"id": "c1", "data": "lang:ja", "message": {"chat": {"id": 77, "type": "private"}}}
    telegram.handle_choice(cb)
    assert sent[-1][1]["text"] == telegram.WELCOME["ja"]
    telegram.handle(_msg("hello", lang="en"))        # Telegram says English, but the person picked Japanese
    assert sent[-1][1]["text"] == telegram.NO_LINK["ja"]
    # the link reply uses the chosen language too
    telegram.handle(_msg("https://x.com/a/status/1230000000000", lang="en"))
    worker.process(worker.claim_next())
    assert "/v/" in sent[-1][1]["text"] and "ダウンロード" in sent[-1][1]["text"] or "お楽しみ" in sent[-1][1]["text"]


def test_telegram_language_guess():
    from figclip import telegram
    assert telegram._guess("zh-hans") == "zh" and telegram._guess("zh-TW") == "zh-TW"
    assert telegram._guess("fa") == "fa" and telegram._guess("de") == "en" and telegram._guess(None) == "en"
    assert set(telegram.WELCOME) == set(telegram.NO_LINK) == set(telegram.SLOW) == set(telegram.FAILED) == set(telegram.TOO_LONG) == telegram.CODES


# ---------------- other video sites
def test_supported_sources(monkeypatch):
    from figclip import safety
    monkeypatch.setattr(safety.S, "YOUTUBE_ENABLED", True, raising=False)
    yt = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
    assert safety.supported_source("https://youtu.be/dQw4w9WgXcQ?si=abc") == yt
    assert safety.supported_source("https://www.youtube.com/shorts/dQw4w9WgXcQ") == yt
    assert safety.supported_source("https://m.youtube.com/watch?v=dQw4w9WgXcQ&t=5") == yt
    assert safety.cache_key(yt) == "yt:dQw4w9WgXcQ"
    assert safety.supported_source("https://www.youtube.com/channel/abc") is None
    assert safety.supported_source("https://www.tiktok.com/@user/video/7300000000000000000?is_from_webapp=1") == \
        "https://www.tiktok.com/@user/video/7300000000000000000"
    assert safety.supported_source("https://vm.tiktok.com/ZMabc123/") == "https://vm.tiktok.com/ZMabc123/"
    assert safety.supported_source("https://www.tiktok.com/@user") is None
    assert safety.supported_source("https://evil.example/watch?v=dQw4w9WgXcQ") is None
    assert safety.supported_source("https://x.com/a/status/2118608069420872063") is not None


def test_telegram_finds_any_supported_link(monkeypatch):
    from figclip import telegram, safety
    assert telegram.find_video_link("https://youtu.be/dQw4w9WgXcQ") is None   # YouTube is off by default
    monkeypatch.setattr(safety.S, "YOUTUBE_ENABLED", True, raising=False)
    assert telegram.find_video_link("look https://youtu.be/dQw4w9WgXcQ!") == "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
    assert telegram.find_video_link("https://example.com/x") is None


def test_youtube_single_quality():
    from figclip import engine
    mk = lambda *tiers: [{"tier": t, "approx_size": 50 * 1024 * 1024} for t in tiers]
    assert engine.pick_single(mk(1080, 720, 480, 360), "yt_free")["tier"] == 480
    assert engine.pick_single(mk(1080, 720, 360), "yt_free")["tier"] == 360   # no 480: best below it
    assert engine.pick_single(mk(360, 240), "yt_free")["tier"] == 360          # low video: its best
    assert engine.pick_single(mk(720), "yt_free")["tier"] == 720               # nothing below 480: the lowest
    assert engine.pick_single(mk(1080, 720, 480), "yt_member")["tier"] == 1080
    assert engine.pick_single(mk(720, 480), "yt_member")["tier"] == 720
    assert engine.pick_single(mk(480, 360), "yt_member")["tier"] == 480        # low video: its best
    big = mk(1080, 720)
    big[0]["approx_size"] = 900 * 1024 * 1024
    assert engine.pick_single(big, "yt_member")["tier"] == 720                 # 1080 too large: 720
    assert engine.pick_single([], "yt_free") is None


def test_youtube_cache_key_differs_for_members():
    from figclip import worker, db
    u = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
    a = worker.enqueue(u, user_id=None, is_member=False)
    b = worker.enqueue(u, user_id=None, is_member=True)
    keys = {r["key"] for r in db.conn().execute("SELECT key FROM jobs")}
    assert {"yt:dQw4w9WgXcQ:f", "yt:dQw4w9WgXcQ:m"} <= keys and a and b


def test_tiktok_uses_browser_impersonation():
    from figclip import engine
    assert engine._extra("https://vt.tiktok.com/ZSp6SnAx9/") == ["--impersonate", "chrome"]
    assert engine._extra("https://www.tiktok.com/@a/video/1") == ["--impersonate", "chrome"]
    assert engine._extra("https://x.com/i/status/2118608069420872063") == []
    assert engine._extra("https://nottiktok.com/a") == []


def test_telegram_stats_owner_only(monkeypatch):
    from figclip import telegram
    sent = []
    monkeypatch.setattr(telegram, "say", lambda chat, text, *a, **k: sent.append((chat, text)))
    monkeypatch.setattr(telegram.S, "TG_OWNER_ID", "111", raising=False)
    msg = lambda chat, text: {"chat": {"id": chat, "type": "private"}, "message_id": 1, "text": text, "from": {}}
    telegram.handle(msg(222, "/stats"))
    assert sent == []                                   # a stranger gets nothing
    telegram.handle(msg(111, "/stats"))
    assert sent and "FigClip stats" in sent[-1][1] and "Telegram" in sent[-1][1]
    telegram.handle(msg(222, "/myid"))
    assert "222" in sent[-1][1]


def test_daily_limit_x_and_telegram(monkeypatch):
    from figclip import telegram, xapi
    monkeypatch.setattr(S, "DAILY_FREE", 2, raising=False)
    monkeypatch.setattr(S, "X_BOT_USER_ID", "1")
    replies = []
    class C:
        def __init__(self, n): self.n = n
        def mentions(self, since):
            return [{"id": str(900 + self.n), "author_id": "77", "handle": "bob", "lang": "en",
                     "refs": [{"type": "replied_to", "id": str(1230000000000 + self.n)}], "urls": []}]
        def tweet(self, tid): return {"id": tid, "lang": "en", "has_video": True, "urls": []}
        def reply(self, tid, text): replies.append((tid, text))
    monkeypatch.setattr(S, "X_DRY_RUN", False, raising=False)
    for n in (1, 2, 3, 4):
        worker.poll_once(C(n))
    n_jobs = db.conn().execute("SELECT COUNT(*) FROM jobs WHERE author_x_id='77'").fetchone()[0]
    assert n_jobs == 2                                    # the 3rd and 4th were refused
    assert len(replies) == 1 and "Daily limit" in replies[0][1] and replies[0][1].startswith("@bob ")
    # Telegram: the same limit, always answered
    sent = []
    monkeypatch.setattr(telegram, "say", lambda chat, text, *a, **k: sent.append(text))
    msg = lambda i: {"chat": {"id": 5, "type": "private"}, "message_id": i, "from": {}, "text": f"https://x.com/i/status/21186080694208720{i:02d}"}
    for i in (10, 11, 12):
        telegram.handle(msg(i))
    assert any("Daily limit" in t or "الحد اليومي" in t for t in sent)
    assert db.conn().execute("SELECT COUNT(*) FROM jobs WHERE tg_chat_id='5'").fetchone()[0] == 2
