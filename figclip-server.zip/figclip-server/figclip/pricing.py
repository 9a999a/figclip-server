"""Membership prices. Must match the numbers shown on the website (app.html)."""
import math
import secrets
from decimal import Decimal, ROUND_DOWN

from .config import S

# months -> (discount percent, membership days)
PLANS = {
    1: (0, 30),
    3: (0, 90),
    6: (10, 180),
    12: (25, 365),
}
PAYPAL_PCT = Decimal("0.049")
PAYPAL_FIXED = Decimal("0.30")
PAYPAL_ROUND = Decimal("0.50")


def valid_months(m):
    return m in PLANS


def days_for(months):
    return PLANS[months][1]


def base_price(months):
    """Price in USD when paying with crypto."""
    pct = Decimal(PLANS[months][0])
    p = Decimal(S.PRICE_PER_MONTH) * months * (Decimal(100) - pct) / Decimal(100)
    return p.quantize(Decimal("0.01"))


def paypal_price(months):
    """Base price plus PayPal's fee (4.9% + 0.30), rounded DOWN to the nearest 0.50."""
    base = base_price(months)
    gross = (base + PAYPAL_FIXED) / (Decimal(1) - PAYPAL_PCT)
    steps = math.floor(gross / PAYPAL_ROUND)
    return (Decimal(steps) * PAYPAL_ROUND).quantize(Decimal("0.01"))


def price_for(months, method):
    return base_price(months) if method == "usdt" else paypal_price(months)


def unique_usdt_amount(months, taken):
    """Base price plus a tiny unique extra (0.0001 .. 0.0500) so each pending order has its own amount."""
    base = base_price(months)
    for _ in range(500):
        extra = Decimal(secrets.randbelow(500) + 1) / Decimal(10000)
        amount = (base + extra).quantize(Decimal("0.0001"), rounding=ROUND_DOWN)
        if str(amount) not in taken:
            return amount
    raise RuntimeError("no free amount")
