"""Settings, read once from environment variables (.env on the server).

Secrets (X keys, PayPal secret, Binance key, SMTP password) live only in .env on the server.
"""
import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()


def _s(name, default=""):
    return os.getenv(name, default).strip()


def _i(name, default):
    try:
        return int(_s(name, str(default)))
    except ValueError:
        return default


def _b(name, default=False):
    return _s(name, "1" if default else "0").lower() in ("1", "true", "yes", "on")


class Settings:
    def __init__(self):
        # --- addresses ---
        self.SITE_ORIGIN = _s("SITE_ORIGIN", "https://figclip.com").rstrip("/")
        self.PUBLIC_BASE_URL = _s("PUBLIC_BASE_URL", "https://api.figclip.com").rstrip("/")
        self.SECRET_KEY = _s("SECRET_KEY", "change-me-in-env")
        self.COOKIE_SECURE = _b("COOKIE_SECURE", True)
        self.DEV_MODE = _b("DEV_MODE", False)  # enables /api/dev/* test endpoints. Never on in production.

        # --- storage ---
        self.DB_PATH = _s("DB_PATH", "/srv/figclip/data/figclip.db")
        self.FILES_DIR = Path(_s("FILES_DIR", "/srv/figclip/files"))
        self.MIN_FREE_BYTES = _i("MIN_FREE_BYTES", 5 * 1024 ** 3)  # stop accepting jobs below this

        # --- download rules ---
        self.YTDLP = _s("YTDLP_BIN", "/usr/local/bin/yt-dlp")
        self.FREE_MAX_SECONDS = _i("FREE_MAX_SECONDS", 20 * 60)
        self.MEMBER_MAX_SECONDS = _i("MEMBER_MAX_SECONDS", 3 * 60 * 60)
        self.MAX_FILESIZE = _s("MAX_FILESIZE", "1500M")  # yt-dlp syntax
        self.PROBE_TIMEOUT = _i("PROBE_TIMEOUT", 60)
        self.DOWNLOAD_TIMEOUT = _i("DOWNLOAD_TIMEOUT", 900)
        self.FREE_BELOW_TIER = _i("FREE_BELOW_TIER", 720)  # free users: shorter side below this
        self.MAX_OPTIONS = _i("MAX_OPTIONS", 3)
        self.ALLOW_PRIVATE_URLS = _b("ALLOW_PRIVATE_URLS", False)  # tests only

        # --- retention ---
        self.FREE_LINK_SECONDS = _i("FREE_LINK_SECONDS", 2 * 3600)
        self.GRACE_SECONDS = _i("GRACE_SECONDS", 7 * 86400)
        self.WARN2_BEFORE_SECONDS = _i("WARN2_BEFORE_SECONDS", 2 * 86400)

        # --- queue ---
        self.QUEUE_MAX_WAIT = _i("QUEUE_MAX_WAIT", 60)
        self.WORKERS = _i("WORKERS", 2)
        self.POLL_SECONDS = _i("POLL_SECONDS", 20)

        # --- X ---
        self.TG_BOT_TOKEN = _s("TG_BOT_TOKEN")  # empty = Telegram bot off
        self.TG_PER_HOUR = _i("TG_PER_HOUR", 30)  # requests per chat per hour
        self.X_ENABLED = _b("X_ENABLED", False)
        self.X_DRY_RUN = _b("X_DRY_RUN", True)  # log replies instead of posting
        self.X_BOT_HANDLE = _s("X_BOT_HANDLE", "FigClipBot").lstrip("@")
        self.X_BOT_USER_ID = _s("X_BOT_USER_ID")
        self.X_BEARER_TOKEN = _s("X_BEARER_TOKEN")
        self.X_API_KEY = _s("X_API_KEY")
        self.X_API_SECRET = _s("X_API_SECRET")
        self.X_ACCESS_TOKEN = _s("X_ACCESS_TOKEN")
        self.X_ACCESS_SECRET = _s("X_ACCESS_SECRET")
        self.X_OAUTH_CLIENT_ID = _s("X_OAUTH_CLIENT_ID")        # for "link my X account"
        self.X_OAUTH_CLIENT_SECRET = _s("X_OAUTH_CLIENT_SECRET")
        self.X_API_BASE = _s("X_API_BASE", "https://api.x.com")
        self.FOLLOW_CHECK = _s("FOLLOW_CHECK", "off")  # off | mentions (free: read from the mention call) | api (costly)
        self.FOLLOW_TTL = _i("FOLLOW_TTL", 86400)

        # --- payments ---
        self.PRICE_PER_MONTH = _s("PRICE_PER_MONTH", "1.00")
        self.ORDER_TTL = _i("ORDER_TTL", 30 * 60)
        self.PAYPAL_ENV = _s("PAYPAL_ENV", "sandbox")
        self.PAYPAL_CLIENT_ID = _s("PAYPAL_CLIENT_ID")
        self.PAYPAL_SECRET = _s("PAYPAL_SECRET")
        self.BINANCE_API_KEY = _s("BINANCE_API_KEY")
        self.BINANCE_API_SECRET = _s("BINANCE_API_SECRET")
        self.USDT_ADDRESS = _s("USDT_ADDRESS")
        self.USDT_NETWORK = _s("USDT_NETWORK", "TRC20")
        self.USDT_TOLERANCE = _s("USDT_TOLERANCE", "0.50")  # accepted shortfall (network fees), never shown to users

        # --- email (password reset, support copy) ---
        self.SMTP_HOST = _s("SMTP_HOST")
        self.SMTP_PORT = _i("SMTP_PORT", 587)
        self.SMTP_USER = _s("SMTP_USER")
        self.SMTP_PASSWORD = _s("SMTP_PASSWORD")
        self.MAIL_FROM = _s("MAIL_FROM", "FigClip Bot <no-reply@figclip.com>")
        self.SUPPORT_EMAIL = _s("SUPPORT_EMAIL")


S = Settings()
