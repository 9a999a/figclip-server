import time

import pytest

from figclip import db, library, pricing, safety, worker, xapi
from figclip.config import S

ORIGIN = {"Origin": "https://figclip.com"}


def register(client, email="a@b.com", pw="password1"):
    r = client.post("/api/auth/register", json={"email": email, "password": pw}, headers=ORIGIN)
    assert r.status_code == 200, r.json
    return r


def run_job(url="https://x.com/i/status/1230000000000", **kw):
    jid = worker.enqueue(url, **kw)
    assert jid
    job = worker.claim_next()
    worker.process(job)
    return job


def token_for(key="x:1230000000000"):
    return library.get_by_key(key)["token"]


# ---------------- pricing
def test_prices():
    assert str(pricing.price_for(1, "usdt")) == "5.00"
    assert str(pricing.price_for(3, "usdt")) == "15.00"
    assert str(pricing.price_for(6, "usdt")) == "27.00"
    assert str(pricing.price_for(12, "usdt")) == "45.00"
    assert str(pricing.price_for(1, "paypal")) == "5.50"
    assert str(pricing.price_for(12, "paypal")) == "47.50"
    assert [pricing.days_for(m) for m in (1, 3, 6, 12)] == [30, 90, 180, 365]


# ---------------- safety
@pytest.mark.parametrize("url", ["http://127.0.0.1/a", "http://localhost/a", "file:///etc/passwd", "ftp://x.com/a",
                                 "http://10.0.0.1/a", "https://user:pw@example.com/a", "http://example.com:22/a",
                                 "http://169.254.169.254/latest"])
def test_unsafe_urls(url):
    with pytest.raises(safety.UnsafeURL):
        safety.validate_url(url)


def test_x_canonical():
    assert safety.canonical_source("https://twitter.com/foo/status/1230000000000?s=20") == "https://x.com/i/status/1230000000000"
    assert safety.cache_key("https://x.com/i/status/1230000000000") == "x:1230000000000"


# ---------------- auth
def test_register_login_logout(client):
    register(client)
    assert client.get("/api/me").json["email"] == "a@b.com"
    client.post("/api/auth/logout", headers=ORIGIN)
    assert client.get("/api/me").status_code == 401
    assert client.post("/api/auth/login", json={"email": "a@b.com", "password": "bad"}, headers=ORIGIN).status_code == 401
    assert client.post("/api/auth/login", json={"email": "a@b.com", "password": "password1"}, headers=ORIGIN).status_code == 200


def test_duplicate_and_weak(client):
    register(client)
    assert client.post("/api/auth/register", json={"email": "a@b.com", "password": "password1"}, headers=ORIGIN).status_code == 409
    assert client.post("/api/auth/register", json={"email": "c@b.com", "password": "123"}, headers=ORIGIN).status_code == 400


def test_bad_origin_rejected(client):
    r = client.post("/api/auth/login", json={"email": "a@b.com", "password": "x"}, headers={"Origin": "https://evil.com"})
    assert r.status_code == 403


def test_login_rate_limit(client):
    register(client)
    codes = [client.post("/api/auth/login", json={"email": "a@b.com", "password": "bad"}, headers=ORIGIN).status_code
             for _ in range(10)]
    assert 429 in codes


def test_password_reset(client):
    from figclip import auth
    register(client)
    uid = db.conn().execute("SELECT id FROM users").fetchone()["id"]
    tok = auth.make_reset_token(uid)
    assert client.post("/api/auth/reset", json={"token": tok, "password": "newpassword"}, headers=ORIGIN).status_code == 200
    assert client.post("/api/auth/reset", json={"token": tok, "password": "another123"}, headers=ORIGIN).status_code == 400
    assert client.post("/api/auth/login", json={"email": "a@b.com", "password": "newpassword"}, headers=ORIGIN).status_code == 200


def test_forgot_same_answer(client):
    assert client.post("/api/auth/forgot", json={"email": "nobody@x.com"}, headers=ORIGIN).json == {"ok": True}


# ---------------- queue
def test_queue_followers_first_then_waiting_jump():
    now = int(time.time())
    a = worker.enqueue("https://x.com/i/status/10000000000", tweet_id="t1", is_follower=False)
    b = worker.enqueue("https://x.com/i/status/20000000000", tweet_id="t2", is_follower=True)
    assert worker.claim_next()["id"] == b          # follower first
    c = db.conn()
    c.execute("UPDATE jobs SET status='queued' WHERE id=?", (b,))
    c.execute("UPDATE jobs SET enqueued_at=? WHERE id=?", (now - 120, a))  # a has waited > 60 s
    assert worker.claim_next()["id"] == a          # waiting request jumps ahead


def test_duplicate_tweet_ignored():
    assert worker.enqueue("https://x.com/i/status/10000000000", tweet_id="t1")
    assert worker.enqueue("https://x.com/i/status/10000000000", tweet_id="t1") is None


def test_blocked_not_fetched():
    db.conn().execute("INSERT INTO blocked VALUES ('x:90000000000','takedown',0)")
    assert worker.enqueue("https://x.com/i/status/90000000000") is None


# ---------------- link page and downloads
def test_free_visitor_sees_locked_tiers(client):
    run_job()
    info = client.get(f"/api/link/{token_for()}").json
    tiers = {o["tier"]: o for o in info["options"]}
    assert not tiers[480]["locked"] and "url" in tiers[480]
    assert tiers[720]["locked"] and "url" not in tiers[720]
    assert tiers[1080]["locked"] and "url" not in tiers[1080]
    assert info["seconds_left"] > 7000


def test_locked_download_refused(client):
    run_job()
    t = token_for()
    assert client.get(f"/dl/{t}/480").status_code == 200
    assert client.get(f"/dl/{t}/1080").status_code == 403
    assert client.get(f"/dl/{t}/999").status_code == 404
    assert client.get("/dl/nonsense/480").status_code == 404


def test_file_is_served_exactly(client):
    run_job()
    r = client.get(f"/dl/{token_for()}/480")
    assert r.data == b"x" * 4800  # untouched bytes


def test_member_gets_all(client):
    register(client)
    uid = db.conn().execute("SELECT id FROM users").fetchone()["id"]
    library.extend_membership(uid, 30)
    run_job()
    assert client.get(f"/dl/{token_for()}/1080").status_code == 200
    info = client.get(f"/api/link/{token_for()}").json
    assert not any(o["locked"] for o in info["options"])


def test_free_link_expires(client):
    run_job()
    t = token_for()
    db.conn().execute("UPDATE videos SET expires_at=?", (int(time.time()) - 1,))
    assert client.get(f"/api/link/{t}").status_code == 410
    assert client.get(f"/dl/{t}/480").status_code == 404
    library.cleanup()
    assert library.get_by_key("x:1230000000000") is None


def test_path_traversal(client):
    run_job()
    assert client.get("/dl/..%2f..%2fetc/480").status_code == 404


# ---------------- member library
def test_downloads_list_locked_for_free_user(client):
    register(client)
    uid = db.conn().execute("SELECT id FROM users").fetchone()["id"]
    run_job(user_id=uid)
    items = client.get("/api/downloads").json["items"]
    assert len(items) == 1 and items[0]["locked"] and "link" not in items[0]
    library.extend_membership(uid, 30)
    items = client.get("/api/downloads").json["items"]
    assert not items[0]["locked"] and items[0]["link"]


def test_member_video_survives_expiry_and_grace():
    from figclip import library as L
    u = db.conn().execute("INSERT INTO users (email, pw_hash, created_at, member_until) VALUES ('m@x.com','x',0,?)",
                          (int(time.time()) + 86400,)).lastrowid
    run_job(user_id=u, is_member=True)
    db.conn().execute("UPDATE videos SET expires_at=?", (int(time.time()) - 10,))
    L.cleanup()
    assert L.get_by_key("x:1230000000000") is not None            # member still active
    db.conn().execute("UPDATE users SET member_until=?", (int(time.time()) - S.GRACE_SECONDS - 10,))
    L.cleanup()
    assert L.get_by_key("x:1230000000000") is None                # grace over


def test_reply_mode_dm_members_only(client):
    register(client)
    assert client.post("/api/me/reply-mode", json={"mode": "dm"}, headers=ORIGIN).status_code == 403
    uid = db.conn().execute("SELECT id FROM users").fetchone()["id"]
    library.extend_membership(uid, 30)
    assert client.post("/api/me/reply-mode", json={"mode": "dm"}, headers=ORIGIN).status_code == 200


# ---------------- payments
def test_usdt_order_flow(client, monkeypatch):
    from figclip import payments
    register(client)
    r = client.post("/api/orders", json={"months": 3, "method": "usdt"}, headers=ORIGIN)
    assert r.status_code == 200, r.json
    o = r.json
    assert float(o["amount"]) >= 15.0001 and o["address"] == "TTestAddress"
    monkeypatch.setattr(payments, "binance_deposits", lambda since: [
        {"amount": o["amount"], "txId": "tx1", "insertTime": int(time.time() * 1000), "status": 1, "coin": "USDT", "address": "TTestAddress"}])
    monkeypatch.setattr(payments, "_last_check", {}, raising=False)
    s = client.get(f"/api/order/{o['id']}").json
    assert s["status"] == "paid"
    me = client.get("/api/me").json
    assert me["member"] and 89 <= me["days_left"] <= 90
    client.get(f"/api/order/{o['id']}")  # polling again must not extend twice
    assert 89 <= client.get("/api/me").json["days_left"] <= 90


def test_bad_order_inputs(client):
    register(client)
    assert client.post("/api/orders", json={"months": 2, "method": "usdt"}, headers=ORIGIN).status_code == 400
    assert client.post("/api/orders", json={"months": 1, "method": "cash"}, headers=ORIGIN).status_code == 400
    assert client.post("/api/orders", json={"months": True, "method": "usdt"}, headers=ORIGIN).status_code == 400


def test_other_users_order_hidden(client):
    register(client)
    oid = client.post("/api/orders", json={"months": 1, "method": "usdt"}, headers=ORIGIN).json["id"]
    other = client.application.test_client()
    other.post("/api/auth/register", json={"email": "z@b.com", "password": "password1"}, headers=ORIGIN)
    assert other.get(f"/api/order/{oid}").status_code in (403, 404)


# ---------------- X
def test_reply_languages():
    assert "الرابط" in xapi.reply_text("ar", "U") or "رابط" in xapi.reply_text("ar", "U")
    assert xapi.pick_lang("und", "ja") == "ja" or xapi.pick_lang("und") == "en"
    assert xapi.pick_lang("xx") == "en"


def test_poll_once_dry_run(monkeypatch):
    class C:
        def mentions(self, since):
            return [{"id": "500", "author_id": "7", "handle": "bob", "lang": "ar", "refs": [{"type": "replied_to", "id": "1230000000000"}], "urls": []}]
        def tweet(self, tid):
            return {"id": tid, "lang": "ar", "has_video": True, "urls": []}
    monkeypatch.setattr(S, "X_BOT_USER_ID", "1")
    worker.poll_once(C())
    job = worker.claim_next()
    assert job["key"] == "x:1230000000000" and job["tweet_id"] == "500"
    worker.process(job)
    assert db.conn().execute("SELECT status FROM jobs").fetchone()["status"] == "done"


def test_no_video_stays_silent(monkeypatch):
    class C:
        def mentions(self, since):
            return [{"id": "501", "author_id": "7", "handle": "bob", "lang": "en", "refs": [], "urls": []}]
        def tweet(self, tid):
            return {"id": tid, "lang": "en", "has_video": False, "urls": []}
    monkeypatch.setattr(S, "X_BOT_USER_ID", "1")
    worker.poll_once(C())
    assert worker.claim_next() is None


def test_failed_build_is_silent(monkeypatch):
    from figclip import engine
    def boom(*a, **k):
        raise engine.EngineError("nope")
    monkeypatch.setattr(engine, "build", boom)
    jid = worker.enqueue("https://x.com/i/status/550000000000", tweet_id="t55")
    worker.process(worker.claim_next())
    assert db.conn().execute("SELECT status FROM jobs WHERE id=?", (jid,)).fetchone()["status"] == "failed"
    assert library.get_by_key("x:550000000000") is None


def test_too_long(monkeypatch):
    from figclip import engine
    def long(*a, **k):
        raise engine.TooLong(5000, 1200)
    monkeypatch.setattr(engine, "build", long)
    jid = worker.enqueue("https://x.com/i/status/560000000000", tweet_id="t56")
    worker.process(worker.claim_next())
    assert db.conn().execute("SELECT status FROM jobs WHERE id=?", (jid,)).fetchone()["status"] == "too_long"


def test_support(client):
    assert client.post("/api/support", json={"message": "hi", "email": "q@x.com"}, headers=ORIGIN).status_code == 200
    assert client.post("/api/support", json={"message": "", "email": "q@x.com"}, headers=ORIGIN).status_code == 400
