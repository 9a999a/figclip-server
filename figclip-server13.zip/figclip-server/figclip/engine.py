"""Download engine: asks yt-dlp what the source offers and downloads those variants exactly as they are.

Rules:
  * Never resize, re-encode or upscale. We offer only what the source already has.
  * When picture and sound are separate, yt-dlp joins them with a stream copy (no re-encode).
  * A variant's "tier" is the SHORTER side of the picture (so a 720x960 phone video is tier 720).
  * We keep the best variant of each tier and offer at most MAX_OPTIONS of the highest tiers.
"""
import json
import os
import signal
import subprocess
from pathlib import Path
from urllib.parse import urlsplit

from .config import S


class EngineError(Exception):
    pass


class TooLong(EngineError):
    def __init__(self, duration, limit):
        super().__init__(f"video is {duration}s, limit {limit}s")
        self.duration, self.limit = duration, limit


def _env():
    home = Path(S.FILES_DIR).parent / "ytdlp-home"
    home.mkdir(parents=True, exist_ok=True)
    return {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": str(home), "LANG": "C.UTF-8"}


def _run(args, timeout):
    p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                         env=_env(), start_new_session=True)
    try:
        out, err = p.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(p.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        p.communicate()
        raise EngineError("timeout")
    return p.returncode, out, err


def _extra(url):
    """TikTok refuses plain requests from a server, so it is fetched while impersonating a Chrome browser."""
    host = (urlsplit(url).hostname or "").lower()
    return ["--impersonate", "chrome"] if host == "tiktok.com" or host.endswith(".tiktok.com") else []


def probe(url):
    """Ask yt-dlp about the video (no download). Returns {duration, title, formats}."""
    code, out, err = _run([S.YTDLP, "-J", "--no-playlist", "--no-warnings", "--socket-timeout", "20", *_extra(url), "--", url],
                          S.PROBE_TIMEOUT)
    if code != 0:
        lines = (err or "").strip().splitlines()
        raise EngineError("probe failed: " + lines[-1][:200] if lines else "probe failed")
    try:
        info = json.loads(out)
    except ValueError:
        raise EngineError("bad probe output")
    if info.get("_type") == "playlist":
        entries = [e for e in info.get("entries") or [] if e]
        if not entries:
            raise EngineError("empty playlist")
        info = entries[0]
    return {"duration": int(info.get("duration") or 0), "title": (info.get("title") or "")[:200],
            "formats": info.get("formats") or []}


def tier_of(f):
    sides = [v for v in (f.get("width"), f.get("height")) if isinstance(v, (int, float)) and v > 0]
    return int(min(sides)) if sides else None


def choose_variants(formats, max_options=None):
    """Pick the best variant of each tier, highest tiers first."""
    max_options = max_options or S.MAX_OPTIONS
    audio = [f for f in formats if f.get("vcodec") == "none" and f.get("acodec") not in (None, "none")]
    best_audio = max(audio, key=lambda f: f.get("abr") or f.get("tbr") or 0, default=None)
    best = {}
    for f in formats:
        if f.get("ext") == "mhtml" or f.get("vcodec") == "none" or not f.get("format_id"):
            continue
        t = tier_of(f)
        if t is None:
            continue
        progressive = f.get("acodec") != "none"
        if progressive:
            selector = f["format_id"]
        elif best_audio:
            selector = f"{f['format_id']}+{best_audio['format_id']}"
        else:
            continue
        score = (progressive, f.get("tbr") or 0)
        if t not in best or score > best[t][0]:
            best[t] = (score, {"tier": t, "width": f.get("width"), "height": f.get("height"),
                               "selector": selector, "approx_size": f.get("filesize") or f.get("filesize_approx")})
    return [best[t][1] for t in sorted(best, reverse=True)[:max_options]]


def pick_single(variants, plan):
    """YouTube keeps ONE quality per download.
    yt_free   -> 480p; if the video has no 480p, the best one below it; if nothing is below, the lowest one.
    yt_member -> 1080p when it exists and is not huge (about 700 MB or less), otherwise 720p;
                 if the video is lower than that, the best one it has."""
    by = {v["tier"]: v for v in variants}
    tiers = sorted(by)
    if not tiers:
        return None
    if plan == "yt_free":
        below = [t for t in tiers if t <= 480]
        return by[max(below)] if below else by[tiers[0]]
    big = 700 * 1024 * 1024
    if 1080 in by and (by[1080].get("approx_size") or 0) <= big:
        return by[1080]
    if 720 in by:
        return by[720]
    below = [t for t in tiers if t <= 1080]
    return by[max(below)] if below else by[tiers[0]]


def download_variant(url, variant, dest_dir):
    """Download one variant into dest_dir. Returns {file, size}."""
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)
    tier = variant["tier"]
    code, _, err = _run([
        S.YTDLP, "-f", variant["selector"], "--no-playlist", "--no-warnings", "--no-progress",
        "--max-filesize", S.MAX_FILESIZE, "--socket-timeout", "20", "--retries", "2",
        "--no-part", "--no-mtime", "--merge-output-format", "mp4",
        "-o", str(dest_dir / f"{tier}.%(ext)s"), *_extra(url), "--", url,
    ], S.DOWNLOAD_TIMEOUT)
    files = [p for p in dest_dir.glob(f"{tier}.*") if p.suffix not in (".part", ".ytdl", ".tmp")]
    if code != 0 or not files:
        raise EngineError("download failed")
    f = max(files, key=lambda p: p.stat().st_size)
    return {"file": f.name, "size": f.stat().st_size}


def build(url, dest_dir, max_seconds, plan=None):
    """Probe, check the length, download the chosen variants. Returns {duration, title, variants}."""
    info = probe(url)
    if info["duration"] and info["duration"] > max_seconds:
        raise TooLong(info["duration"], max_seconds)
    if plan:  # one quality only (YouTube)
        one = pick_single(choose_variants(info["formats"], 99), plan)
        chosen = [one] if one else []
    else:
        chosen = choose_variants(info["formats"])
    if not chosen:
        raise EngineError("no downloadable video")
    variants = []
    for v in chosen:
        got = download_variant(url, v, dest_dir)
        variants.append({"tier": v["tier"], "width": v["width"], "height": v["height"], **got})
    return {"duration": info["duration"], "title": info["title"], "variants": variants}
