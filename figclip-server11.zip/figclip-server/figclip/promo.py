"""Hourly promo post: 24 original tweets (12 languages x 2), one per hour, rotating.
Each tweet is about the bot itself and uses its own relevant hashtags (no hijacking of unrelated trends)."""
import logging
import time

from . import xapi
from .config import S

log = logging.getLogger("figclip.promo")

TWEETS = [
    ("ar", "🤖 أنا بوت تابع للحساب.\nإذا شفت فيديو على X أو TikTok منشنّي @FigClipBot وأوصله لجهازك.\n✈️ متاح أيضا على تيليجرام\nfigclip.com\n#تحميل_فيديو #FigClip"),
    ("ar", "🎬 شفت فيديو يعجبك؟ منشنّي @FigClipBot تحته وأرسله لجهازك من X أو TikTok.\n🤖 أنا بوت تابع للحساب، وموجود كذلك على تيليجرام.\nfigclip.com\n#تحميل_فيديوهات #تيك_توك"),
    ("en", "🤖 I'm the account's bot.\nSee a video on X or TikTok? Mention @FigClipBot and I'll send it to your device.\n✈️ Also available on Telegram\nfigclip.com\n#VideoDownloader #FigClip"),
    ("en", "🎬 Spot a video you like? Mention @FigClipBot under it and I'll get it onto your device, from X or TikTok.\n🤖 I'm this account's bot, and I'm on Telegram too.\nfigclip.com\n#TikTokDownloader #FigClip"),
    ("ja", "🤖 このアカウントのボットです。\nXやTikTokで動画を見つけたら @FigClipBot にメンションしてください。あなたの端末に届けます。\n✈️ Telegramでも利用できます\nfigclip.com\n#動画保存 #FigClip"),
    ("ja", "🎬 気になる動画を見つけたら、下に @FigClipBot とメンション。XでもTikTokでも、端末へお届けします。\n🤖 アカウントのボットで、Telegramにも対応しています。\nfigclip.com\n#動画ダウンロード #TikTok保存"),
    ("th", "🤖 ฉันเป็นบอทของบัญชีนี้\nเจอวิดีโอบน X หรือ TikTok แท็ก @FigClipBot แล้วฉันจะส่งไปที่อุปกรณ์ของคุณ\n✈️ ใช้บน Telegram ได้ด้วย\nfigclip.com\n#โหลดคลิป #FigClip"),
    ("th", "🎬 เจอวิดีโอที่ชอบ? แท็ก @FigClipBot ใต้โพสต์ แล้วรับไปไว้ในเครื่องได้ทั้งจาก X และ TikTok\n🤖 เป็นบอทประจำบัญชี และมีบน Telegram ด้วย\nfigclip.com\n#โหลดวิดีโอ #โหลดTikTok"),
    ("es", "🤖 Soy el bot de esta cuenta.\n¿Ves un video en X o TikTok? Menciona a @FigClipBot y te lo envío a tu dispositivo.\n✈️ También disponible en Telegram\nfigclip.com\n#DescargarVideos #FigClip"),
    ("es", "🎬 ¿Viste un video que te gustó? Menciona a @FigClipBot debajo y lo llevo a tu dispositivo, desde X o TikTok.\n🤖 Soy el bot de la cuenta y también estoy en Telegram.\nfigclip.com\n#DescargarTikTok #FigClip"),
    ("pt", "🤖 Sou o bot desta conta.\nViu um vídeo no X ou no TikTok? Marque @FigClipBot e eu envio para o seu dispositivo.\n✈️ Também disponível no Telegram\nfigclip.com\n#BaixarVideos #FigClip"),
    ("pt", "🎬 Gostou de um vídeo? Marque @FigClipBot embaixo e eu levo ele para o seu dispositivo, do X ou do TikTok.\n🤖 Sou o bot da conta e também estou no Telegram.\nfigclip.com\n#BaixarTikTok #FigClip"),
    ("ru", "🤖 Я бот этого аккаунта.\nУвидели видео в X или TikTok? Упомяните @FigClipBot — и я отправлю его на ваше устройство.\n✈️ Доступен и в Telegram\nfigclip.com\n#СкачатьВидео #FigClip"),
    ("ru", "🎬 Понравилось видео? Упомяните @FigClipBot под ним, и я доставлю его на ваше устройство из X или TikTok.\n🤖 Я бот аккаунта, есть и в Telegram.\nfigclip.com\n#СкачатьTikTok #FigClip"),
    ("tr", "🤖 Ben bu hesabın botuyum.\nX veya TikTok'ta bir video mu gördün? @FigClipBot'u etiketle, cihazına göndereyim.\n✈️ Telegram'da da var\nfigclip.com\n#Videoİndir #FigClip"),
    ("tr", "🎬 Beğendiğin bir video mu var? Altına @FigClipBot yaz, X'ten ya da TikTok'tan cihazına ulaştırayım.\n🤖 Hesabın botuyum, Telegram'da da varım.\nfigclip.com\n#TikTokİndir #FigClip"),
    ("id", "🤖 Aku bot dari akun ini.\nLihat video di X atau TikTok? Mention @FigClipBot dan aku kirim ke perangkatmu.\n✈️ Tersedia juga di Telegram\nfigclip.com\n#UnduhVideo #FigClip"),
    ("id", "🎬 Ada video yang kamu suka? Mention @FigClipBot di bawahnya, aku antar ke perangkatmu dari X atau TikTok.\n🤖 Aku bot akun ini dan ada juga di Telegram.\nfigclip.com\n#UnduhTikTok #FigClip"),
    ("hi", "🤖 मैं इस अकाउंट का बॉट हूँ।\nX या TikTok पर कोई वीडियो दिखे तो @FigClipBot को मेंशन करें, मैं उसे आपके डिवाइस तक पहुँचा दूँगा।\n✈️ Telegram पर भी उपलब्ध\nfigclip.com\n#वीडियोडाउनलोड #FigClip"),
    ("hi", "🎬 कोई वीडियो पसंद आया? उसके नीचे @FigClipBot मेंशन करें, मैं X या TikTok से उसे आपके डिवाइस पर भेज दूँगा।\n🤖 मैं अकाउंट का बॉट हूँ और Telegram पर भी हूँ।\nfigclip.com\n#TikTokडाउनलोड #FigClip"),
    ("zh", "🤖 我是这个账号的机器人。\n在 X 或 TikTok 看到视频，@FigClipBot 我，我就把它送到你的设备。\n✈️ 也支持 Telegram\nfigclip.com\n#视频下载 #FigClip"),
    ("zh", "🎬 看到喜欢的视频？在下面 @FigClipBot，我把 X 或 TikTok 上的视频送到你的设备。\n🤖 我是账号机器人，Telegram 上也有。\nfigclip.com\n#TikTok下载 #FigClip"),
    ("ko", "🤖 저는 이 계정의 봇이에요.\nX나 TikTok에서 영상을 보면 @FigClipBot 을 멘션하세요. 기기로 보내 드릴게요.\n✈️ 텔레그램에서도 사용 가능\nfigclip.com\n#영상저장 #FigClip"),
    ("ko", "🎬 마음에 드는 영상이 있나요? 아래에 @FigClipBot 을 멘션하면 X나 TikTok 영상을 기기로 보내 드려요.\n🤖 계정 봇이고 텔레그램에도 있어요.\nfigclip.com\n#틱톡다운로드 #FigClip"),
]


def _weighted_len(text):
    """X counts URLs as 23 chars and CJK/most non-Latin ranges as 2."""
    n = 0
    for w in text.replace("\n", " \n ").split(" "):
        if w.startswith("figclip.com"):
            n += 23
            continue
        for ch in w:
            n += 2 if ord(ch) >= 0x1100 and (ord(ch) < 0x2000 or ord(ch) > 0x2FFF) and ch not in "⚡🎬" else 1
        n += 1
    return n


def due(now=None):
    return int(now or time.time()) - int(xapi_state("promo_last", 0)) >= 3600


def xapi_state(key, default=None):
    from . import worker
    return worker._state(key, default)


def post_next(client):
    if not S.PROMO_ENABLED or client is None:
        return
    from . import worker
    now = int(time.time())
    if now - int(worker._state("promo_last", 0)) < 3600:
        return
    idx = int(worker._state("promo_idx", 0)) % len(TWEETS)
    lang, text = TWEETS[idx]
    if S.PROMO_TRENDS:
        try:
            from . import trends
            tag = trends.pick_for(lang)
            if tag and _weighted_len(text + " " + tag) <= 280:
                text = text + " " + tag
        except Exception as e:  # never block the post because the trends site failed
            log.warning("trend hashtag skipped: %s", e)
    worker._set_state("promo_last", now)      # set first: a crash must never cause a double post
    worker._set_state("promo_idx", idx + 1)
    if S.X_DRY_RUN:
        log.info("DRY RUN promo #%d (%s): %s", idx + 1, lang, text.replace("\n", " | "))
        return
    try:
        client.post(text)
        log.info("promo #%d (%s) posted", idx + 1, lang)
    except Exception as e:
        log.warning("promo post failed: %s", e)
