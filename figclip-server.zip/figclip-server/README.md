# FigClip server

Two programs share one SQLite file:
- web: `gunicorn wsgi:app` (API for the site, link pages, file downloads)
- worker: `python -m figclip.worker` (reads X mentions, downloads, replies)

## Local test
    pip install -r requirements.txt pytest
    python -m pytest tests

## Server install (Ubuntu 24.04, user `figclip`)
    cd /srv/figclip/app && python3 -m venv venv && venv/bin/pip install -r requirements.txt
    cp .env.example .env     # then fill it in on the server only
    sudo cp deploy/*.service /etc/systemd/system/ && sudo systemctl daemon-reload
    sudo systemctl enable --now figclip-web figclip-worker
    sudo cp deploy/Caddyfile /etc/caddy/Caddyfile && sudo systemctl reload caddy

## Admin
    venv/bin/python manage.py stats | grant EMAIL DAYS | takedown TWEET_ID | cleanup

Keep X_ENABLED=0 and X_DRY_RUN=1 until the X keys are in and a small test is done.
