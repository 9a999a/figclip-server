"""Talking to X (Twitter) API v2, plus reply texts in several languages.

NOTE: this module has not been run against the real X API yet. It needs your keys and a small test credit.
Every call costs money on the pay-per-use plan, so the poller asks for as little as possible.
"""
import re
import time
from urllib.parse import urlsplit

import requests
from requests_oauthlib import OAuth1

from .config import S

LANG_UNKNOWN = {"", "und", "qam", "qct", "qht", "qme", "qst", "zxx", None}

REPLY = {
    "en": "Your download link is ready, enjoy 😊\n{url}",
    "ar": "رابط التحميل جاهز، استمتع 😊\n{url}",
    "es": "Tu enlace de descarga está listo, disfruta 😊\n{url}",
    "fr": "Ton lien de téléchargement est prêt, profite 😊\n{url}",
    "de": "Dein Download-Link ist fertig, viel Spaß 😊\n{url}",
    "pt": "Seu link de download está pronto, aproveite 😊\n{url}",
    "it": "Il tuo link di download è pronto, buon divertimento 😊\n{url}",
    "tr": "İndirme bağlantın hazır, keyfini çıkar 😊\n{url}",
    "id": "Tautan unduhanmu sudah siap, selamat menikmati 😊\n{url}",
    "ru": "Ссылка для скачивания готова, наслаждайтесь 😊\n{url}",
    "ja": "ダウンロードリンクの準備ができました。お楽しみください 😊\n{url}",
    "ko": "다운로드 링크가 준비되었습니다. 즐겨보세요 😊\n{url}",
    "fa": "لینک دانلود شما آماده است، لذت ببرید 😊\n{url}",
    "hi": "आपका डाउनलोड लिंक तैयार है, आनंद लें 😊\n{url}",
    "zh": "你的下载链接已准备好，请享用 😊\n{url}",
    "zh-TW": "你的下載連結已準備好，請享用 😊\n{url}",
}
TOO_LONG = {
    "en": "This video is longer than {minutes} minutes. Members can download longer videos: {site}",
    "ar": "هذا الفيديو أطول من {minutes} دقيقة. المشتركون يستطيعون تحميل الفيديوهات الأطول: {site}",
}


def pick_lang(*codes):
    """First language code that is a real language and one we have a template for; otherwise English."""
    for code in codes:
        if code not in LANG_UNKNOWN:
            base = str(code).split("-")[0].lower()
            return base if base in REPLY else "en"
    return "en"


def reply_text(lang, url):
    return REPLY.get(lang, REPLY["en"]).format(url=url)


def with_handle(handle, text):
    """Start the reply with @name so the person who asked is tagged."""
    h = str(handle or "").lstrip("@")
    if h and re.fullmatch(r"[A-Za-z0-9_]{1,15}", h):
        return f"@{h} {text}"
    return text


def too_long_text(lang, minutes):
    return TOO_LONG.get(lang, TOO_LONG["en"]).format(minutes=minutes, site=S.SITE_ORIGIN)


class XError(Exception):
    pass


class XClient:
    def __init__(self, session=None):
        self.http = session or requests.Session()
        self.base = S.X_API_BASE

    # -- auth helpers
    def _bearer(self):
        return {"Authorization": f"Bearer {S.X_BEARER_TOKEN}"}

    def _oauth1(self):
        return OAuth1(S.X_API_KEY, S.X_API_SECRET, S.X_ACCESS_TOKEN, S.X_ACCESS_SECRET)

    def _get(self, path, params, user_context=False):
        if user_context:
            r = self.http.get(self.base + path, params=params, auth=self._oauth1(), timeout=20)
        else:
            r = self.http.get(self.base + path, params=params, headers=self._bearer(), timeout=20)
        if r.status_code == 429:
            raise XError("rate limited")
        if r.status_code >= 400:
            raise XError(f"GET {path} -> {r.status_code}")
        return r.json()

    def _post(self, path, payload):
        r = self.http.post(self.base + path, json=payload, auth=self._oauth1(), timeout=20)
        if r.status_code >= 400:
            raise XError(f"POST {path} -> {r.status_code}")
        return r.json()

    # -- reading
    def mentions(self, since_id=None):
        """New mentions of the bot, oldest first. Returns a list of dicts."""
        params = {"max_results": 50, "tweet.fields": "lang,referenced_tweets,author_id,entities,created_at",
                  "expansions": "author_id", "user.fields": "username"}
        if since_id:
            params["since_id"] = since_id
        want_follow = S.FOLLOW_CHECK == "mentions"
        if want_follow:
            # connection_status says whether the asker follows the bot; it needs the bot's own (user-context) auth
            params["user.fields"] = "username,connection_status"
            try:
                data = self._get(f"/2/users/{S.X_BOT_USER_ID}/mentions", params, user_context=True)
            except XError:
                want_follow = False  # fall back: no follower priority, but the bot keeps working
                params["user.fields"] = "username"
                data = self._get(f"/2/users/{S.X_BOT_USER_ID}/mentions", params)
        else:
            data = self._get(f"/2/users/{S.X_BOT_USER_ID}/mentions", params)
        inc = (data.get("includes") or {}).get("users", [])
        users = {u["id"]: u.get("username") for u in inc}
        follows = {u["id"]: "followed_by" in (u.get("connection_status") or []) for u in inc}
        out = []
        for t in reversed(data.get("data") or []):
            out.append({"id": t["id"], "author_id": t.get("author_id"), "handle": users.get(t.get("author_id")),
                        "is_follower": follows.get(t.get("author_id"), False),
                        "lang": t.get("lang"), "refs": t.get("referenced_tweets") or [],
                        "urls": [u.get("expanded_url") for u in (t.get("entities") or {}).get("urls", [])
                                 if u.get("expanded_url")]})
        return out

    def tweet(self, tweet_id):
        data = self._get(f"/2/tweets/{tweet_id}", {
            "tweet.fields": "lang,entities,attachments,referenced_tweets",
            "expansions": "attachments.media_keys", "media.fields": "type"})
        t = data.get("data") or {}
        media = (data.get("includes") or {}).get("media", [])
        return {"id": t.get("id"), "lang": t.get("lang"),
                "has_video": any(m.get("type") in ("video", "animated_gif") for m in media),
                "urls": [u.get("expanded_url") for u in (t.get("entities") or {}).get("urls", [])
                         if u.get("expanded_url")]}

    # -- writing
    def reply(self, to_tweet_id, text):
        return self._post("/2/tweets", {"text": text, "reply": {"in_reply_to_tweet_id": to_tweet_id}})

    def dm(self, user_id, text):
        return self._post(f"/2/dm_conversations/with/{user_id}/messages", {"text": text})


def is_x_host(url):
    return (urlsplit(url).hostname or "").lower() in {
        "x.com", "www.x.com", "twitter.com", "www.twitter.com", "mobile.twitter.com", "t.co"}


def find_source(client, mention):
    """Work out which video the user means. Returns (source_url, lang_of_video_tweet) or (None, None).

    Order: the tweet being replied to, a quoted tweet, then the mention tweet itself.
    A tweet counts if it has an X video, or a link to an outside website.
    """
    candidates = [r["id"] for r in mention["refs"] if r.get("type") == "replied_to"]
    candidates += [r["id"] for r in mention["refs"] if r.get("type") == "quoted"]
    candidates.append(mention["id"])
    for tid in candidates:
        t = client.tweet(tid)
        if t["has_video"]:
            return f"https://x.com/i/status/{tid}", t["lang"]
        for u in t["urls"]:
            if not is_x_host(u):
                return u, t["lang"]
    return None, None


def follower_status(client, author_id):
    """Follower check is OFF until we measure what it costs. See FOLLOW_CHECK in .env."""
    if S.FOLLOW_CHECK != "api":
        return False
    from . import db
    c = db.conn()
    row = c.execute("SELECT is_follower, checked_at FROM follow_cache WHERE x_user_id=?", (author_id,)).fetchone()
    if row and time.time() - row["checked_at"] < S.FOLLOW_TTL:
        return bool(row["is_follower"])
    try:
        data = client._get(f"/2/users/{author_id}/following", {"max_results": 1000})
        # costly on big accounts; kept simple on purpose until we know the price
        ids = {u["id"] for u in data.get("data") or []}
        val = S.X_BOT_USER_ID in ids
    except XError:
        return False
    c.execute("INSERT OR REPLACE INTO follow_cache VALUES (?,?,?)", (author_id, 1 if val else 0, int(time.time())))
    return val
