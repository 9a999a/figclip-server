"""Membership orders: USDT (matched by a unique amount on a Binance deposit) and PayPal.

The server confirms every payment itself. The browser is never trusted.
"""
import hashlib
import logging
import hmac
import secrets
import sqlite3
import time
from decimal import Decimal
from urllib.parse import urlencode

import requests

from . import db, library, pricing
from .config import S

log = logging.getLogger("figclip.payments")


class PayError(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def _now():
    return int(time.time())


def create_order(user_id, months, method):
    if not pricing.valid_months(months):
        raise PayError("Invalid duration")
    if method not in ("usdt", "paypal"):
        raise PayError("Invalid payment method")
    if method == "usdt" and not (S.USDT_ADDRESS and S.BINANCE_API_KEY and S.BINANCE_API_SECRET):
        raise PayError("USDT payments are not available yet", 503)
    if method == "paypal" and not (S.PAYPAL_CLIENT_ID and S.PAYPAL_SECRET):
        raise PayError("PayPal payments are not available yet", 503)
    c = db.conn()
    oid = secrets.token_urlsafe(12)
    t = _now()
    crypto = None
    if method == "usdt":
        taken = {r[0] for r in c.execute(
            "SELECT crypto_amount FROM orders WHERE status='pending' AND crypto_amount IS NOT NULL AND created_at>?",
            (t - S.ORDER_TTL,))}
        crypto = str(pricing.unique_usdt_amount(months, taken))
    c.execute(
        "INSERT INTO orders (id, user_id, months, days, method, price, crypto_amount, assigned_ms, created_at)"
        " VALUES (?,?,?,?,?,?,?,?,?)",
        (oid, user_id, months, pricing.days_for(months), method,
         str(pricing.price_for(months, method)), crypto, t * 1000 if crypto else None, t))
    return oid


def get_order(oid, user_id):
    row = db.conn().execute("SELECT * FROM orders WHERE id=? AND user_id=?", (oid, user_id)).fetchone()
    if row is None:
        raise PayError("Order not found", 404)
    return row


def _expired(o):
    return o["status"] == "pending" and _now() - o["created_at"] > S.ORDER_TTL


def mark_paid(order, **extra):
    """Mark an order paid once and extend the membership. Safe to call twice."""
    c = db.conn()
    fields = {"status": "paid", "paid_at": _now(), **extra}
    sets = ", ".join(f"{k}=?" for k in fields)
    cur = c.execute(f"UPDATE orders SET {sets} WHERE id=? AND status='pending'", (*fields.values(), order["id"]))
    if cur.rowcount == 1:
        library.extend_membership(order["user_id"], order["days"])
        library.notify(order["user_id"], f"Payment received. Membership extended by {order['days']} days.")
        return True
    return False


def view(o):
    expired = _expired(o)
    data = {
        "id": o["id"],
        "status": "expired" if expired else o["status"],
        "product": f"Membership ({o['days']} days)",
        "method": o["method"],
        "price": o["price"],
        "expires_in": max(0, S.ORDER_TTL - (_now() - o["created_at"])) if o["status"] == "pending" else 0,
    }
    if o["method"] == "usdt":
        data.update(amount=o["crypto_amount"], address=S.USDT_ADDRESS, network=S.USDT_NETWORK)
    return data


# ---------------------------------------------------------------- USDT via Binance deposit history (read-only key)
def binance_deposits(since_ms):
    params = {"coin": "USDT", "status": 1, "startTime": since_ms,
              "timestamp": int(time.time() * 1000), "recvWindow": 10000}
    query = urlencode(params)
    sig = hmac.new(S.BINANCE_API_SECRET.encode(), query.encode(), hashlib.sha256).hexdigest()
    r = requests.get(f"https://api.binance.com/sapi/v1/capital/deposit/hisrec?{query}&signature={sig}",
                     headers={"X-MBX-APIKEY": S.BINANCE_API_KEY}, timeout=15)
    r.raise_for_status()
    return r.json()


_last_reconcile = 0


def reconcile():
    """Match Binance deposits to pending USDT orders.

    An exact amount match always wins. Otherwise a deposit up to USDT_TOLERANCE below the order amount
    (network fees taken out by the sender) is accepted, but only when exactly one open order could own it.
    """
    global _last_reconcile
    if _now() - _last_reconcile < 5:
        return
    _last_reconcile = _now()
    c = db.conn()
    orders = c.execute("SELECT * FROM orders WHERE status='pending' AND method='usdt' AND created_at>?",
                       (_now() - S.ORDER_TTL,)).fetchall()
    if not orders:
        return
    try:
        deposits = binance_deposits(min(o["assigned_ms"] for o in orders))
    except requests.RequestException:
        return
    tol = Decimal(str(S.USDT_TOLERANCE))
    for dep in deposits:
        try:
            if not (dep.get("status") == 1 and dep.get("txId")
                    and str(dep.get("coin", "USDT")).upper() == "USDT"
                    and (not dep.get("network") or str(dep["network"]).upper() == S.USDT_NETWORK.upper())):
                continue
            amt = Decimal(str(dep["amount"]))
        except Exception:
            continue
        if c.execute("SELECT 1 FROM orders WHERE txid=?", (dep["txId"],)).fetchone():
            continue  # already used
        open_orders = [o for o in orders if o["status"] == "pending"
                       and (not dep.get("insertTime") or int(dep["insertTime"]) >= o["assigned_ms"] - 60000)]
        exact = [o for o in open_orders if Decimal(o["crypto_amount"]) == amt]
        close = [o for o in open_orders if Decimal(o["crypto_amount"]) - tol <= amt < Decimal(o["crypto_amount"])]
        pick = exact[0] if exact else (close[0] if len(close) == 1 else None)
        if pick is None:
            if len(close) > 1:
                log.warning("deposit %s of %s fits several open orders; leaving it for manual review", dep["txId"], amt)
            continue
        try:
            mark_paid(pick, txid=dep["txId"])
        except sqlite3.IntegrityError:
            continue
        orders = [o if o["id"] != pick["id"] else {**dict(o), "status": "paid"} for o in orders]


def check_usdt(o):
    if o["status"] != "pending" or o["method"] != "usdt" or _expired(o):
        return o
    reconcile()
    return db.conn().execute("SELECT * FROM orders WHERE id=?", (o["id"],)).fetchone()


def sweep():
    """Called by the worker: confirm USDT payments even when the customer closed the page."""
    if S.BINANCE_API_KEY and S.BINANCE_API_SECRET:
        reconcile()


# ---------------------------------------------------------------- PayPal
def _pp_base():
    return "https://api-m.paypal.com" if S.PAYPAL_ENV == "live" else "https://api-m.sandbox.paypal.com"


def _pp_token():
    r = requests.post(_pp_base() + "/v1/oauth2/token", auth=(S.PAYPAL_CLIENT_ID, S.PAYPAL_SECRET),
                      data={"grant_type": "client_credentials"}, timeout=15)
    r.raise_for_status()
    return r.json()["access_token"]


def paypal_create(o):
    if o["method"] != "paypal" or o["status"] != "pending" or _expired(o):
        raise PayError("Order is not payable", 409)
    try:
        r = requests.post(
            _pp_base() + "/v2/checkout/orders",
            headers={"Authorization": f"Bearer {_pp_token()}"},
            json={"intent": "CAPTURE", "purchase_units": [{
                "custom_id": o["id"], "description": f"FigClip membership ({o['days']} days)",
                "amount": {"currency_code": "USD", "value": o["price"]}}]},
            timeout=15)
        r.raise_for_status()
    except requests.RequestException:
        raise PayError("Could not start PayPal checkout", 502)
    pp_id = r.json()["id"]
    db.conn().execute("UPDATE orders SET paypal_order_id=? WHERE id=?", (pp_id, o["id"]))
    return pp_id


def paypal_capture(o):
    if o["status"] == "paid":
        return o
    if not o["paypal_order_id"] or o["method"] != "paypal":
        raise PayError("No PayPal checkout started for this order")
    try:
        r = requests.post(f"{_pp_base()}/v2/checkout/orders/{o['paypal_order_id']}/capture",
                          headers={"Authorization": f"Bearer {_pp_token()}", "Content-Type": "application/json"},
                          timeout=15)
        r.raise_for_status()
        res = r.json()
        cap = res["purchase_units"][0]["payments"]["captures"][0]
        ok = (res.get("status") == "COMPLETED" and cap.get("status") == "COMPLETED"
              and cap["amount"]["currency_code"] == "USD"
              and Decimal(cap["amount"]["value"]) == Decimal(o["price"]))
    except (requests.RequestException, KeyError, IndexError, ValueError):
        raise PayError("Could not confirm PayPal payment", 502)
    if ok:
        mark_paid(o)
    return db.conn().execute("SELECT * FROM orders WHERE id=?", (o["id"],)).fetchone()
