"""Stored videos: one link per video, free links die after 2 hours, member files stay while the membership
is active (plus a 7-day grace period with two warnings)."""
import json
import secrets
import shutil
import time

from . import db
from .config import S


def now():
    return int(time.time())


def tier_allowed(tier, is_member):
    return bool(is_member) or tier < S.FREE_BELOW_TIER


def is_member(user, at=None):
    return bool(user) and user["member_until"] > (at or now())


def video_dir(video_id):
    return S.FILES_DIR / str(video_id)


def get_by_key(key):
    return db.conn().execute("SELECT * FROM videos WHERE key=?", (key,)).fetchone()


def get_by_token(token):
    return db.conn().execute("SELECT * FROM videos WHERE token=?", (token,)).fetchone()


def get_by_id(video_id):
    return db.conn().execute("SELECT * FROM videos WHERE id=?", (video_id,)).fetchone()


def try_create(key, source_url, label):
    """Create the row for a new build. Returns the new video id, or None if the key already exists."""
    t = now()
    cur = db.conn().execute(
        "INSERT OR IGNORE INTO videos (key, token, source_url, label, status, created_at, expires_at)"
        " VALUES (?,?,?,?, 'queued', ?, ?)",
        (key, secrets.token_urlsafe(9), source_url, label, t, t + 3600))
    return cur.lastrowid if cur.rowcount == 1 else None


def mark_ready(video_id, duration, variants):
    t = now()
    db.conn().execute(
        "UPDATE videos SET status='ready', duration=?, variants=?, created_at=?, expires_at=? WHERE id=?",
        (duration, json.dumps(variants), t, t + S.FREE_LINK_SECONDS, video_id))


def mark_failed(video_id):
    db.conn().execute("UPDATE videos SET status='failed' WHERE id=?", (video_id,))


def delete_video(video_id):
    shutil.rmtree(video_dir(video_id), ignore_errors=True)
    db.conn().execute("DELETE FROM videos WHERE id=?", (video_id,))


def remember(user_id, video_id, label, member):
    db.conn().execute(
        "INSERT INTO user_videos (user_id, video_id, label, at, member_at_request) VALUES (?,?,?,?,?)"
        " ON CONFLICT(user_id, video_id) DO UPDATE SET at=excluded.at,"
        " member_at_request=MAX(member_at_request, excluded.member_at_request)",
        (user_id, video_id, label, now(), 1 if member else 0))


def link_open(video, user):
    """May this visitor use the link right now?"""
    if video is None or video["status"] != "ready":
        return False
    t = now()
    if t < video["expires_at"]:
        return True
    if is_member(user, t):
        row = db.conn().execute(
            "SELECT 1 FROM user_videos WHERE user_id=? AND video_id=? AND member_at_request=1",
            (user["id"], video["id"])).fetchone()
        return row is not None
    return False


def variants_of(video):
    return json.loads(video["variants"] or "[]")


def view_variants(video, user):
    """What the link page shows. Locked tiers have no url for non-members."""
    member = is_member(user)
    out = []
    for v in variants_of(video):
        locked = not tier_allowed(v["tier"], member)
        item = {"tier": v["tier"], "label": f"{v['tier']}p", "size": v["size"], "locked": locked}
        if not locked:
            item["url"] = f"{S.PUBLIC_BASE_URL}/dl/{video['token']}/{v['tier']}"
        out.append(item)
    return out


# ---------------------------------------------------------------- cleanup
def _retained(video_id, t):
    row = db.conn().execute(
        "SELECT 1 FROM user_videos uv JOIN users u ON u.id = uv.user_id"
        " WHERE uv.video_id=? AND uv.member_at_request=1 AND u.member_until + ? > ? LIMIT 1",
        (video_id, S.GRACE_SECONDS, t)).fetchone()
    return row is not None


def cleanup():
    """Delete expired files, send the two grace-period warnings. Safe to run every few minutes."""
    c = db.conn()
    t = now()
    removed = 0
    for v in c.execute("SELECT id, status, expires_at, created_at FROM videos").fetchall():
        stale_job = v["status"] in ("queued", "failed") and t - v["created_at"] > 3600
        expired = v["status"] == "ready" and t >= v["expires_at"] and not _retained(v["id"], t)
        if stale_job or expired:
            delete_video(v["id"])
            removed += 1
    # warnings for members whose membership ended and who still have retained files
    rows = c.execute(
        "SELECT u.id, u.member_until, u.warn1_sent, u.warn2_sent FROM users u"
        " WHERE u.member_until > 0 AND u.member_until <= ? AND u.member_until + ? > ?"
        " AND EXISTS (SELECT 1 FROM user_videos uv WHERE uv.user_id=u.id AND uv.member_at_request=1)",
        (t, S.GRACE_SECONDS, t)).fetchall()
    for u in rows:
        end = u["member_until"] + S.GRACE_SECONDS
        if not u["warn1_sent"]:
            notify(u["id"], "Your membership ended. Your saved videos will be deleted in 7 days unless you renew.")
            c.execute("UPDATE users SET warn1_sent=1 WHERE id=?", (u["id"],))
        if not u["warn2_sent"] and end - t <= S.WARN2_BEFORE_SECONDS:
            notify(u["id"], "Last warning: your saved videos will be deleted in less than 2 days. Renew to keep them.")
            c.execute("UPDATE users SET warn2_sent=1 WHERE id=?", (u["id"],))
    # pending orders that nobody paid
    c.execute("UPDATE orders SET status='expired' WHERE status='pending' AND created_at < ?", (t - S.ORDER_TTL,))
    # old sessions and tokens
    c.execute("DELETE FROM sessions WHERE expires_at < ?", (t,))
    c.execute("DELETE FROM reset_tokens WHERE expires_at < ?", (t,))
    c.execute("DELETE FROM follow_cache WHERE checked_at < ?", (t - 7 * 86400,))
    return removed


def notify(user_id, text):
    db.conn().execute("INSERT INTO notifications (user_id, text, at) VALUES (?,?,?)", (user_id, text, now()))


def extend_membership(user_id, days):
    c = db.conn()
    t = now()
    row = c.execute("SELECT member_until FROM users WHERE id=?", (user_id,)).fetchone()
    start = max(t, row["member_until"])
    c.execute("UPDATE users SET member_until=?, warn1_sent=0, warn2_sent=0 WHERE id=?",
              (start + days * 86400, user_id))
    return start + days * 86400
