"""URL safety (SSRF protection) and cache keys.

We never fetch a URL that points at the server itself or at a private network.
yt-dlp may still follow redirects, so the downloader also runs as a low-privilege user
and the firewall blocks nothing inbound that matters. This check removes the obvious attacks.
"""
import hashlib
import ipaddress
import re
import socket
from urllib.parse import urlsplit, urlunsplit

from .config import S

MAX_URL = 2000
X_HOSTS = {"x.com", "www.x.com", "twitter.com", "www.twitter.com", "mobile.twitter.com", "mobile.x.com"}
_X_PATH = re.compile(r"^/(?:[A-Za-z0-9_]{1,30}|i(?:/web)?)/status/(\d{5,25})(?:/.*)?$")


YT_HOSTS = {"youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com", "youtu.be", "www.youtu.be"}
TT_HOSTS = {"tiktok.com", "www.tiktok.com", "m.tiktok.com", "vm.tiktok.com", "vt.tiktok.com"}
_YT_ID = re.compile(r"^[A-Za-z0-9_-]{11}$")


class UnsafeURL(ValueError):
    pass


def x_status_id(url):
    """Tweet id if this is an X/Twitter status URL, else None."""
    try:
        p = urlsplit(url)
    except ValueError:
        return None
    if (p.hostname or "").lower() not in X_HOSTS:
        return None
    m = _X_PATH.match(p.path)
    return m.group(1) if m else None


def _check_ip(ip_text):
    ip = ipaddress.ip_address(ip_text)
    if (ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast
            or ip.is_reserved or ip.is_unspecified):
        raise UnsafeURL("address not allowed")
    if getattr(ip, "ipv4_mapped", None):
        _check_ip(str(ip.ipv4_mapped))


def validate_url(url):
    """Return a cleaned URL or raise UnsafeURL."""
    if not isinstance(url, str) or not url or len(url) > MAX_URL:
        raise UnsafeURL("bad url")
    try:
        p = urlsplit(url.strip())
    except ValueError:
        raise UnsafeURL("bad url")
    if p.scheme not in ("http", "https"):
        raise UnsafeURL("only http/https")
    if p.username or p.password:
        raise UnsafeURL("credentials in url")
    host = (p.hostname or "").lower().rstrip(".")
    if not host or host == "localhost" or host.endswith((".localhost", ".local", ".internal")):
        raise UnsafeURL("host not allowed")
    try:
        port = p.port
    except ValueError:
        raise UnsafeURL("bad port")
    if port not in (None, 80, 443):
        raise UnsafeURL("port not allowed")
    if not S.ALLOW_PRIVATE_URLS:
        try:
            infos = socket.getaddrinfo(host, port or (443 if p.scheme == "https" else 80), proto=socket.IPPROTO_TCP)
        except socket.gaierror:
            raise UnsafeURL("host does not resolve")
        if not infos:
            raise UnsafeURL("host does not resolve")
        for info in infos:
            _check_ip(info[4][0])
    return urlunsplit((p.scheme, p.netloc, p.path, p.query, ""))


def cache_key(url):
    """One link per video: X videos by tweet id, everything else by a hash of the URL."""
    tid = x_status_id(url)
    if tid:
        return "x:" + tid
    yid = youtube_id(url)
    if yid:
        return "yt:" + yid
    p = urlsplit(url)
    norm = urlunsplit((p.scheme, (p.hostname or "").lower(), p.path.rstrip("/"), p.query, ""))
    return "u:" + hashlib.sha1(norm.encode()).hexdigest()[:20]


def canonical_source(url):
    """X status links are rewritten to a stable form that yt-dlp understands."""
    tid = x_status_id(url)
    return f"https://x.com/i/status/{tid}" if tid else url


def youtube_id(url):
    """Video id of a youtube.com/watch, /shorts, /live, /embed link or a youtu.be link, else None."""
    try:
        p = urlsplit(url)
    except ValueError:
        return None
    host = (p.hostname or "").lower()
    if host not in YT_HOSTS:
        return None
    if host.endswith("youtu.be"):
        vid = p.path.strip("/").split("/")[0]
    else:
        parts = [x for x in p.path.split("/") if x]
        if parts[:1] == ["watch"]:
            vid = (dict(q.split("=", 1) for q in p.query.split("&") if "=" in q)).get("v", "")
        elif parts[:1] in (["shorts"], ["live"], ["embed"]) and len(parts) > 1:
            vid = parts[1]
        else:
            vid = ""
    return vid if _YT_ID.match(vid or "") else None


def tiktok_url(url):
    """A TikTok video link (full or short), cleaned of tracking parameters, else None."""
    try:
        p = urlsplit(url)
    except ValueError:
        return None
    host = (p.hostname or "").lower()
    if host not in TT_HOSTS or p.scheme not in ("http", "https"):
        return None
    path = p.path.rstrip("/")
    if host in ("vm.tiktok.com", "vt.tiktok.com"):
        return f"https://{host}{path}/" if len(path) > 1 else None
    if "/video/" in path or path.startswith("/t/"):
        return f"https://www.tiktok.com{path}"
    return None


def supported_source(url):
    """The cleaned link if it is an X, YouTube or TikTok video link, else None."""
    if x_status_id(url):
        return url
    vid = youtube_id(url)
    if vid:
        return f"https://www.youtube.com/watch?v={vid}"
    return tiktok_url(url)
