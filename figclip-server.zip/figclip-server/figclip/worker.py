"""The bot: reads mentions from X, queues jobs, downloads, replies. Run with:  python -m figclip.worker

Queue rules:
  * followers go first,
  * but any request that has waited QUEUE_MAX_WAIT seconds (60) jumps to the front, first come first served,
  * one attempt only. If anything fails, the bot stays silent.
"""
import logging
import shutil
import threading
import time

from . import db, engine, library, safety, xapi
from .config import S

log = logging.getLogger("figclip.worker")


# ---------------------------------------------------------------- queue
def enqueue(source_url, tweet_id=None, author_x_id=None, author_handle=None, lang=None,
            is_follower=False, user_id=None, is_member=False):
    """Add a job. Returns the job id, or None if it was a duplicate or the URL is not allowed."""
    try:
        url = safety.validate_url(safety.canonical_source(source_url))
    except safety.UnsafeURL:
        log.info("rejected url for tweet %s", tweet_id)
        return None
    key = safety.cache_key(url)
    c = db.conn()
    if c.execute("SELECT 1 FROM blocked WHERE key=?", (key,)).fetchone():
        return None
    cur = c.execute(
        "INSERT OR IGNORE INTO jobs (key, source_url, tweet_id, author_x_id, author_handle, lang, is_follower,"
        " user_id, is_member, enqueued_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
        (key, url, tweet_id, author_x_id, author_handle, lang, 1 if is_follower else 0,
         user_id, 1 if is_member else 0, int(time.time())))
    return cur.lastrowid if cur.rowcount == 1 else None


def claim_next():
    c = db.conn()
    t = int(time.time())
    row = c.execute(
        "SELECT id FROM jobs WHERE status='queued' ORDER BY"
        " CASE WHEN :now - enqueued_at >= :wait THEN 0 ELSE 1 END,"
        " CASE WHEN :now - enqueued_at >= :wait THEN 0 ELSE 1 - is_follower END,"
        " enqueued_at, id LIMIT 1", {"now": t, "wait": S.QUEUE_MAX_WAIT}).fetchone()
    if row is None:
        return None
    cur = c.execute("UPDATE jobs SET status='running' WHERE id=? AND status='queued'", (row["id"],))
    if cur.rowcount != 1:
        return None
    return c.execute("SELECT * FROM jobs WHERE id=?", (row["id"],)).fetchone()


def _finish(job_id, status, note=None):
    db.conn().execute("UPDATE jobs SET status=?, note=? WHERE id=?", (status, note, job_id))


# ---------------------------------------------------------------- one job
def _wait_for(key, seconds=180):
    end = time.time() + seconds
    while time.time() < end:
        v = library.get_by_key(key)
        if v is None or v["status"] != "queued":
            return v
        time.sleep(1)
    return library.get_by_key(key)


def _label(info_title, url):
    t = (info_title or "").strip()
    return t[:60] if t else "Video"


def ensure_video(job):
    """Return (video_row, error). error is None, 'too_long', 'failed' or 'skipped'."""
    key, url = job["key"], job["source_url"]
    member = bool(job["is_member"])
    limit = S.MEMBER_MAX_SECONDS if member else S.FREE_MAX_SECONDS
    t = int(time.time())

    existing = library.get_by_key(key)
    if existing is not None and existing["status"] == "queued":
        existing = _wait_for(key)
    if existing is not None and existing["status"] == "ready":
        if t >= existing["expires_at"]:
            if library._retained(existing["id"], t):
                db.conn().execute("UPDATE videos SET expires_at=? WHERE id=?",
                                  (t + S.FREE_LINK_SECONDS, existing["id"]))
                existing = library.get_by_id(existing["id"])
            else:
                library.delete_video(existing["id"])
                existing = None
        if existing is not None:
            if not member and (existing["duration"] or 0) > S.FREE_MAX_SECONDS:
                return None, "too_long"
            return existing, None
    elif existing is not None:  # failed or vanished
        library.delete_video(existing["id"])

    free = shutil.disk_usage(S.FILES_DIR if S.FILES_DIR.exists() else S.FILES_DIR.parent).free
    if free < S.MIN_FREE_BYTES:
        return None, "skipped"

    vid = library.try_create(key, url, "Video")
    if vid is None:  # another worker just started the same video
        v = _wait_for(key)
        return (v, None) if v is not None and v["status"] == "ready" else (None, "failed")
    try:
        built = engine.build(url, library.video_dir(vid), limit)
    except engine.TooLong:
        library.delete_video(vid)
        return None, "too_long"
    except Exception as e:  # EngineError, timeouts, anything unexpected: one attempt, stay silent
        log.warning("build failed for %s: %s", key, e)
        library.delete_video(vid)
        return None, "failed"
    db.conn().execute("UPDATE videos SET label=? WHERE id=?", (_label(built["title"], url), vid))
    library.mark_ready(vid, built["duration"], built["variants"])
    return library.get_by_id(vid), None


def deliver(job, video, client):
    """Send the link: public reply by default, DM if the member chose it."""
    if not job["tweet_id"]:
        return
    lang = xapi.pick_lang(job["lang"])
    link = f"{S.SITE_ORIGIN}/v/{video['token']}"
    user = None
    if job["user_id"]:
        user = db.conn().execute("SELECT * FROM users WHERE id=?", (job["user_id"],)).fetchone()
    use_dm = bool(user) and library.is_member(user) and user["reply_mode"] == "dm" and job["author_x_id"]
    text = xapi.reply_text(lang, link)
    if S.X_DRY_RUN:
        log.info("DRY RUN %s to %s: %s", "DM" if use_dm else "reply", job["tweet_id"], text.replace("\n", " "))
        return
    try:
        if use_dm:
            client.dm(job["author_x_id"], text)
            library.notify(user["id"], f"Link sent to your DMs: {video['label']}")
        else:
            client.reply(job["tweet_id"], text)
    except Exception as e:
        log.warning("reply failed for job %s: %s", job["id"], e)


def process(job, client=None):
    video, error = ensure_video(job)
    if error == "too_long":
        _finish(job["id"], "too_long")
        if job["tweet_id"] and not S.X_DRY_RUN and client:
            try:
                client.reply(job["tweet_id"], xapi.too_long_text(xapi.pick_lang(job["lang"]), S.FREE_MAX_SECONDS // 60))
            except Exception as e:
                log.warning("too_long reply failed: %s", e)
        return
    if error:
        _finish(job["id"], "failed" if error == "failed" else "skipped", error)
        return
    if job["user_id"]:
        library.remember(job["user_id"], video["id"], video["label"], bool(job["is_member"]))
    deliver(job, video, client)
    _finish(job["id"], "done")


# ---------------------------------------------------------------- polling X
def _state(key, default=None):
    row = db.conn().execute("SELECT v FROM state WHERE k=?", (key,)).fetchone()
    return row["v"] if row else default


def _set_state(key, value):
    db.conn().execute("INSERT OR REPLACE INTO state VALUES (?,?)", (key, str(value)))


def poll_once(client):
    since = _state("since_id")
    mentions = client.mentions(since)
    for m in mentions:
        _set_state("since_id", m["id"])
        if m["author_id"] == S.X_BOT_USER_ID:
            continue
        try:
            source, vid_lang = xapi.find_source(client, m)
        except xapi.XError as e:
            log.warning("could not resolve mention %s: %s", m["id"], e)
            continue
        if not source:
            continue  # no video, no link: stay silent
        user = db.conn().execute("SELECT * FROM users WHERE x_user_id=?", (m["author_id"],)).fetchone()
        enqueue(source, tweet_id=m["id"], author_x_id=m["author_id"], author_handle=m["handle"],
                lang=m["lang"] if m["lang"] not in xapi.LANG_UNKNOWN else vid_lang,
                is_follower=xapi.follower_status(client, m["author_id"]),
                user_id=user["id"] if user else None, is_member=library.is_member(user))


# ---------------------------------------------------------------- run forever
def _loop(name, fn, every):
    while True:
        try:
            fn()
        except Exception:
            log.exception("%s crashed, continuing", name)
        time.sleep(every)


def run():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    S.FILES_DIR.mkdir(parents=True, exist_ok=True)
    client = xapi.XClient() if S.X_ENABLED else None

    def work():
        job = claim_next()
        if job is None:
            time.sleep(1.5)
            return
        try:
            process(job, client)
        except Exception:
            log.exception("job %s crashed", job["id"])
            _finish(job["id"], "failed", "crash")

    threads = [threading.Thread(target=_loop, args=(f"worker{i}", work, 0), daemon=True) for i in range(S.WORKERS)]
    threads.append(threading.Thread(target=_loop, args=("cleanup", library.cleanup, 300), daemon=True))
    if client:
        threads.append(threading.Thread(target=_loop, args=("poller", lambda: poll_once(client), S.POLL_SECONDS),
                                        daemon=True))
    for t in threads:
        t.start()
    log.info("worker running: %d workers, X %s", S.WORKERS, "on" if client else "off")
    while True:
        time.sleep(3600)


if __name__ == "__main__":
    run()
