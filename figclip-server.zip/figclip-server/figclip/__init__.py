"""FigClip server."""
