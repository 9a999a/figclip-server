"""Hashtags that stayed on trends24.in's worldwide list for several of the last hours (not one-hour flashes).
The page is parsed by its timestamp headings + search links, not by CSS class names, so small layout changes survive."""
import re
import time
from urllib.parse import unquote_plus

import requests

from .config import S

URL = "https://trends24.in/"
TS = re.compile(r"[A-Z][a-z]{2} [A-Z][a-z]{2} \d{2} \d{4} (\d{2}):(\d{2}):(\d{2}) GMT")
LINK = re.compile(r"""href=["']https?://(?:www\.)?(?:twitter|x)\.com/search\?q=([^"'&]+)""", re.I)
_cache = {"t": 0, "blocks": None}


AGO = re.compile(r"(?:(\d+)|an?) (hour|minute)s? ago", re.I)


def _marks(html):
    marks = [(m.start(), m.group(0), int(m.group(1)) * 60 + int(m.group(2))) for m in TS.finditer(html)]
    if marks:
        return marks
    # fallback: the "N hours ago" headings the page shows in a browser (older = larger N)
    out = []
    for m in AGO.finditer(html):
        n = int(m.group(1) or 1) * (60 if m.group(2).lower() == "hour" else 1)
        out.append((m.start(), m.group(0), -n))
    return out


def parse(html):
    """-> list of blocks, newest first; each block = ordered list of tags ('#...')."""
    marks = _marks(html)
    blocks = []
    for i, (pos, label, minute) in enumerate(marks):
        end = marks[i + 1][0] if i + 1 < len(marks) else len(html)
        tags = []
        for lm in LINK.finditer(html[pos:end]):
            term = unquote_plus(lm.group(1))
            if term.startswith("#") and term not in tags:
                tags.append(term)
        if not tags:
            continue
        # two snapshots a few minutes apart are one "hour"
        if blocks and abs(blocks[-1][0] - minute) % 1440 < 20:
            continue
        blocks.append((minute, tags))
    return [b[1] for b in blocks]


def script_of(tag):
    t = tag.lstrip("#")
    if re.search(r"[฀-๿]", t): return "th"
    if re.search(r"[가-힯ᄀ-ᇿ]", t): return "ko"
    if re.search(r"[぀-ヿ]", t): return "ja"
    if re.search(r"[ऀ-ॿ]", t): return "hi"
    if re.search(r"[؀-ۿ]", t): return "ar"
    if re.search(r"[Ѐ-ӿ]", t): return "ru"
    if re.search(r"[一-鿿]", t): return "zh"
    if re.search(r"[A-Za-zÀ-ɏ]", t): return "latin"
    return None


def lang_script(lang):
    return "latin" if lang in ("en", "es", "pt", "tr", "id") else lang


def fetch_blocks():
    if _cache["blocks"] is not None and time.time() - _cache["t"] < 1800:
        return _cache["blocks"]
    r = requests.get(URL, headers={"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/124 Safari/537.36",
                                   "Accept-Language": "en"}, timeout=20)
    r.raise_for_status()
    blocks = parse(r.text)
    _cache.update(t=time.time(), blocks=blocks)
    return blocks


def persistent(blocks, hours=5, min_hours=2):
    """Tags present in at least `min_hours` of the newest `hours` blocks, best first."""
    recent = blocks[:hours]
    score = {}
    for b in recent:
        for rank, tag in enumerate(b):
            c, best = score.get(tag, (0, 999))
            score[tag] = (c + 1, min(best, rank))
    ok = [(c, -best, tag) for tag, (c, best) in score.items() if c >= min_hours]
    ok.sort(reverse=True)
    return [t for _, _, t in ok]


def blocked(tag):
    low = tag.lower()
    return any(w and w in low for w in S.PROMO_TAG_BLOCK.lower().split(","))


def pick_for(lang, used=()):
    """One persistent worldwide hashtag written in the script of `lang`, or None."""
    want = lang_script(lang)
    for tag in persistent(fetch_blocks()):
        if script_of(tag) == want and len(tag) <= 32 and not blocked(tag) and tag not in used:
            return tag
    return None


if __name__ == "__main__":
    bl = fetch_blocks()
    print("blocks:", len(bl))
    for lg in ("ar", "en", "ja", "th", "es", "pt", "ru", "tr", "id", "hi", "zh", "ko"):
        print(lg, pick_for(lg))
