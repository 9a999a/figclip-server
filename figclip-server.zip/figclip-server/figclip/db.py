"""SQLite access. One connection per thread; WAL mode so the web server and the worker can share the file."""
import sqlite3
import threading
from pathlib import Path

from .config import S

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  pw_hash TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  x_user_id TEXT UNIQUE,
  x_handle TEXT,
  member_until INTEGER NOT NULL DEFAULT 0,
  reply_mode TEXT NOT NULL DEFAULT 'public',      -- public | dm
  warn1_sent INTEGER NOT NULL DEFAULT 0,
  warn2_sent INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS reset_tokens (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  months INTEGER NOT NULL,
  days INTEGER NOT NULL,
  method TEXT NOT NULL,                            -- usdt | paypal
  price TEXT NOT NULL,                             -- what the customer pays in USD
  crypto_amount TEXT,                              -- unique USDT amount
  assigned_ms INTEGER,
  status TEXT NOT NULL DEFAULT 'pending',          -- pending | paid | expired
  paypal_order_id TEXT,
  txid TEXT UNIQUE,
  created_at INTEGER NOT NULL,
  paid_at INTEGER
);
CREATE TABLE IF NOT EXISTS videos (
  id INTEGER PRIMARY KEY,
  key TEXT NOT NULL UNIQUE,
  token TEXT NOT NULL UNIQUE,
  source_url TEXT NOT NULL,
  label TEXT,
  duration INTEGER,
  status TEXT NOT NULL,                            -- queued | ready | failed
  variants TEXT,                                   -- JSON list
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS user_videos (
  user_id INTEGER NOT NULL,
  video_id INTEGER NOT NULL,
  label TEXT,
  at INTEGER NOT NULL,
  member_at_request INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, video_id)
);
CREATE TABLE IF NOT EXISTS jobs (
  id INTEGER PRIMARY KEY,
  key TEXT NOT NULL,
  source_url TEXT NOT NULL,
  tweet_id TEXT UNIQUE,                            -- the mention we must reply to (NULL for dev jobs)
  author_x_id TEXT,
  author_handle TEXT,
  lang TEXT,
  is_follower INTEGER NOT NULL DEFAULT 0,
  user_id INTEGER,
  is_member INTEGER NOT NULL DEFAULT 0,
  enqueued_at INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'queued',           -- queued | running | done | failed | skipped | too_long
  note TEXT
);
CREATE INDEX IF NOT EXISTS jobs_status ON jobs(status, enqueued_at);
CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL,
  text TEXT NOT NULL,
  at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS support (
  id INTEGER PRIMARY KEY,
  user_id INTEGER,
  email TEXT,
  message TEXT NOT NULL,
  at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS follow_cache (
  x_user_id TEXT PRIMARY KEY,
  is_follower INTEGER NOT NULL,
  checked_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS blocked (
  key TEXT PRIMARY KEY,
  reason TEXT,
  at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS state (
  k TEXT PRIMARY KEY,
  v TEXT
);
"""

_local = threading.local()
_inited = set()
_init_lock = threading.Lock()


def conn():
    path = S.DB_PATH
    c = getattr(_local, "c", None)
    if c is None or getattr(_local, "path", None) != path:
        if c is not None:
            c.close()
        if path != ":memory:":
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        c = sqlite3.connect(path, timeout=30, isolation_level=None)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA foreign_keys=OFF")
        c.execute("PRAGMA busy_timeout=30000")
        _local.c, _local.path = c, path
    with _init_lock:
        if path not in _inited:
            c.executescript(SCHEMA)
            _inited.add(path)
    return c


def reset_for_tests():
    c = getattr(_local, "c", None)
    if c is not None:
        c.close()
    _local.c = None
    _inited.clear()
