"""Admin commands:  python manage.py <command>
  stats                      counts
  grant EMAIL DAYS           give membership days
  takedown TWEET_ID_OR_KEY   delete the video and block it from being fetched again
  cleanup                    run the cleanup once
"""
import sys
import time

from figclip import db, library


def main(argv):
    if not argv:
        print(__doc__)
        return 1
    cmd, args = argv[0], argv[1:]
    c = db.conn()
    if cmd == "stats":
        for t in ("users", "videos", "orders", "jobs", "support"):
            print(t, c.execute(f"SELECT COUNT(*) n FROM {t}").fetchone()["n"])
        print("members", c.execute("SELECT COUNT(*) n FROM users WHERE member_until>?", (int(time.time()),)).fetchone()["n"])
    elif cmd == "grant" and len(args) == 2:
        u = c.execute("SELECT id FROM users WHERE email=?", (args[0].lower(),)).fetchone()
        if not u:
            print("no such user")
            return 1
        library.extend_membership(u["id"], int(args[1]))
        print("done")
    elif cmd == "takedown" and len(args) == 1:
        key = args[0] if ":" in args[0] else f"x:{args[0]}"
        v = library.get_by_key(key)
        if v:
            library.delete_video(v["id"])
        c.execute("INSERT OR REPLACE INTO blocked VALUES (?,?,?)", (key, "takedown", int(time.time())))
        print("removed and blocked", key)
    elif cmd == "cleanup":
        library.cleanup()
        print("done")
    else:
        print(__doc__)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
