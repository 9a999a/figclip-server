import os
import sys
import tempfile
from pathlib import Path

TMP = Path(tempfile.mkdtemp())
os.environ.update({
    "DB_PATH": str(TMP / "t.db"), "FILES_DIR": str(TMP / "files"), "DEV_MODE": "1", "COOKIE_SECURE": "0",
    "SITE_ORIGIN": "https://figclip.com", "PUBLIC_BASE_URL": "https://api.figclip.com",
    "X_DRY_RUN": "1", "MIN_FREE_BYTES": "0", "USDT_ADDRESS": "TTestAddress", "BINANCE_API_KEY": "k",
    "BINANCE_API_SECRET": "s"})
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest  # noqa: E402

from figclip import auth, db, engine  # noqa: E402
from figclip.web import create_app  # noqa: E402


@pytest.fixture(autouse=True)
def fresh(monkeypatch):
    db.reset_for_tests()
    c = db.conn()
    for t in ("users", "sessions", "reset_tokens", "orders", "videos", "user_videos", "jobs", "notifications",
              "support", "follow_cache", "blocked", "state"):
        c.execute(f"DELETE FROM {t}")
    auth.reset_rate_limits()

    def fake_build(url, dest, max_seconds):
        Path(dest).mkdir(parents=True, exist_ok=True)
        out = []
        for tier in (1080, 720, 480):
            f = Path(dest) / f"v{tier}.mp4"
            f.write_bytes(b"x" * (tier * 10))
            out.append({"tier": tier, "width": tier * 16 // 9, "height": tier, "file": f.name, "size": f.stat().st_size})
        return {"title": "Test video", "duration": 30, "variants": out}
    monkeypatch.setattr(engine, "build", fake_build)

    import ipaddress
    import socket
    real = socket.getaddrinfo

    def fake_dns(host, port, *a, **k):
        try:
            ipaddress.ip_address(host)
            return real(host, port, *a, **k)
        except ValueError:
            return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("93.184.216.34", port or 443))]
    monkeypatch.setattr(socket, "getaddrinfo", fake_dns)
    yield


@pytest.fixture
def client():
    return create_app().test_client()
