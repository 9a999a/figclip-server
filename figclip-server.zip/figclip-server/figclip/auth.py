"""Accounts: passwords, login sessions, password reset, small in-memory rate limiter, email sending."""
import hashlib
import re
import secrets
import smtplib
import threading
import time
from email.message import EmailMessage

from werkzeug.security import check_password_hash, generate_password_hash

from . import db
from .config import S

COOKIE = "fc_session"
SESSION_SECONDS = 30 * 86400
RESET_SECONDS = 3600
EMAIL_RE = re.compile(r"^[^\s@]{1,64}@[^\s@]{1,255}\.[^\s@]{2,}$")


def norm_email(email):
    return (email or "").strip().lower()


def valid_email(email):
    return bool(EMAIL_RE.match(email)) and len(email) <= 254


def valid_password(pw):
    return isinstance(pw, str) and 8 <= len(pw) <= 200


def _h(token):
    return hashlib.sha256(token.encode()).hexdigest()


def create_user(email, password):
    c = db.conn()
    try:
        cur = c.execute("INSERT INTO users (email, pw_hash, created_at) VALUES (?,?,?)",
                        (email, generate_password_hash(password), int(time.time())))
    except Exception as e:  # sqlite3.IntegrityError
        if "UNIQUE" in str(e).upper():
            return None
        raise
    return cur.lastrowid


def check_login(email, password):
    row = db.conn().execute("SELECT id, pw_hash FROM users WHERE email=?", (email,)).fetchone()
    if row is None:
        # keep timing similar when the email does not exist
        check_password_hash("scrypt:32768:8:1$x$" + "0" * 128, password)
        return None
    return row["id"] if check_password_hash(row["pw_hash"], password) else None


def new_session(user_id):
    token = secrets.token_urlsafe(32)
    now = int(time.time())
    db.conn().execute("INSERT INTO sessions VALUES (?,?,?,?)", (_h(token), user_id, now, now + SESSION_SECONDS))
    return token


def user_from_token(token):
    if not token:
        return None
    now = int(time.time())
    return db.conn().execute(
        "SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash=? AND s.expires_at>?",
        (_h(token), now)).fetchone()


def end_session(token):
    if token:
        db.conn().execute("DELETE FROM sessions WHERE token_hash=?", (_h(token),))


def end_all_sessions(user_id, keep_token=None):
    keep = _h(keep_token) if keep_token else ""
    db.conn().execute("DELETE FROM sessions WHERE user_id=? AND token_hash<>?", (user_id, keep))


def change_password(user_id, new_password):
    db.conn().execute("UPDATE users SET pw_hash=? WHERE id=?", (generate_password_hash(new_password), user_id))


def make_reset_token(user_id):
    token = secrets.token_urlsafe(32)
    db.conn().execute("INSERT INTO reset_tokens VALUES (?,?,?)", (_h(token), user_id, int(time.time()) + RESET_SECONDS))
    return token


def use_reset_token(token, new_password):
    c = db.conn()
    row = c.execute("SELECT user_id FROM reset_tokens WHERE token_hash=? AND expires_at>?",
                    (_h(token), int(time.time()))).fetchone()
    if row is None:
        return False
    c.execute("DELETE FROM reset_tokens WHERE token_hash=?", (_h(token),))
    change_password(row["user_id"], new_password)
    end_all_sessions(row["user_id"])
    return True


# ---- rate limiting (per process; good enough for login/forgot/support) ----
_hits = {}
_hits_lock = threading.Lock()


def rate_limited(key, limit, window):
    now = time.time()
    with _hits_lock:
        arr = [t for t in _hits.get(key, []) if now - t < window]
        if len(arr) >= limit:
            _hits[key] = arr
            return True
        arr.append(now)
        _hits[key] = arr
        if len(_hits) > 5000:
            for k in [k for k, v in _hits.items() if not v or now - v[-1] > window]:
                _hits.pop(k, None)
    return False


def reset_rate_limits():
    with _hits_lock:
        _hits.clear()


# ---- email ----
def email_configured():
    return bool(S.SMTP_HOST)


def send_email(to, subject, body):
    """Returns True if sent. Does nothing (returns False) when SMTP is not configured."""
    if not email_configured():
        return False
    msg = EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = S.MAIL_FROM, to, subject
    msg.set_content(body)
    try:
        with smtplib.SMTP(S.SMTP_HOST, S.SMTP_PORT, timeout=20) as s:
            s.starttls()
            if S.SMTP_USER:
                s.login(S.SMTP_USER, S.SMTP_PASSWORD)
            s.send_message(msg)
        return True
    except Exception:
        return False
